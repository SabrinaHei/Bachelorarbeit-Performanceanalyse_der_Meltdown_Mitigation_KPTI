##!/bin/bash
sudo cp ./code/grub_settings/grub_kpti /etc/default/grub
sudo update-grub
sudo reboot

