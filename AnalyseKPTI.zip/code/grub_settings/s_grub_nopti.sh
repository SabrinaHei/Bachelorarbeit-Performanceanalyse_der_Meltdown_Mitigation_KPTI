##!/bin/bash
sudo cp ./code/grub_settings/grub_nopti /etc/default/grub
sudo update-grub
sudo reboot
