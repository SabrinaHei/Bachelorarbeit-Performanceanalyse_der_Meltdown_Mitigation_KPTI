#include <stdlib.h>
#include <string.h>

#include "system_specs.h"


//Versionierung der aktuellen Dateien, Variablen durch Makefile gesetzt
char* get_specs(){
    char* ret=malloc(900*sizeof(char));
	memset(ret,'\0',sizeof(900*sizeof(char)));

	//Git-Version
    strcat(ret,"\n> Projekt Version:\t\t");
    #ifndef PROJECT_VERSION
    strcat(ret, "?");
    #else
    strcat(ret, PROJECT_VERSION);
    #endif


    //OS-Version
    strcat(ret, "\n> Betriebssystem:\t\t");
    #ifndef OS_VERSION
    strcat(ret, "?");
    #else
    strcat(ret, OS_VERSION);
    #endif

    //Kernel-Version
    strcat(ret, "\n> Kernel Version:\t\t");
    #ifndef KERNEL_VERSION
    strcat(ret, "?");
    #else
    strcat(ret, KERNEL_VERSION);
	#endif

	//CPU-Modell
	strcat(ret, "\n> CPU Modell:\t\t\t");
	#ifndef CPU_FULLNAME
	strcat(ret, "?");
	#else
	strcat(ret, CPU_FULLNAME);
	#endif

	//TLB
	strcat(ret, "\n> TLB Infos:\t\t\t");
	#ifndef TLB
	strcat(ret, "?");
	#else
	strcat(ret, TLB);
	#endif

	//Cache
	strcat(ret, "\n> Cache Größen:\t\t");
	#ifndef CACHE
	strcat(ret, "?");
	#else
	strcat(ret, CACHE);
	#endif

	//KPTI-On
	strcat(ret, "\n> KPTI On:\t\t\t");
	#ifndef KPTI
	strcat(ret, "?");
	#else
	strcat(ret, KPTI);
	#endif


	//PCID-Available
	strcat(ret, "\n> PCID available:\t\t");
	#ifndef PCID
	strcat(ret, "?");
	#else
	strcat(ret, PCID);
	#endif

	//Microcode
	strcat(ret, "\n> Microcode Version:\t\t");
	#ifndef MICROCODE
	strcat(ret, "?");
	#else
	strcat(ret, MICROCODE);
	#endif

	//CPU Stepping
	strcat(ret, "\n> CPU Stepping:\t\t");
	#ifndef STEPPING
	strcat(ret, "?");
	#else
	strcat(ret, STEPPING);
	#endif

	//Bugs
	strcat(ret, "\n> Bugs:\t\t\t");
	#ifndef BUGS
	strcat(ret, "?");
	#else
	strcat(ret, BUGS);
	#endif



    //Compiler-Version
    strcat(ret, "\n> Compiler Version:\t\t");
    #ifndef COMPILER_VERSION
    strcat(ret, "?");
    #else
    strcat(ret, COMPILER_VERSION);
    #endif


    //Gnuplot-Version
    strcat(ret, "\n> Gnuplot Version:\t\t");
    #ifndef GNUPLOT_VERSION
    strcat(ret, "?");
    #else
    strcat(ret, GNUPLOT_VERSION);
    #endif

    //Datum
    strcat(ret, "\n> Kompilierungs Datum:\t\t");
    #ifndef DATE
    strcat(ret, "?");
    #else
    strcat(ret, DATE);
    #endif


    return ret;
}
