#ifndef VERSION_H
#define VERSION_H
char* get_specs();
#endif