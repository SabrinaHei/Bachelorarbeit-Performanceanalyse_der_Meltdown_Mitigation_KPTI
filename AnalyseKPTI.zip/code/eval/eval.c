#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <math.h>

#include "../analyse/analyse.h"
#include "eval.h"
#include "statistics.h"



//Gnuplot Graph erstellen
void plot(char* command) {
	FILE *gnuplot = popen("gnuplot -persistent", "w");
	fprintf(gnuplot, "%s", command);             //jeweiliger Plot Befehl
	fprintf(gnuplot, "show output\n");          //Anzeige in Welcher Datei die Daten gespeichert wurden

	//gnuplot schließen
	fprintf(gnuplot, "exit\n");
	fflush(gnuplot);
	pclose(gnuplot);

	return;
}

//Bereitet Plot für File Management Systemcalls vor und plottet
void plot_fm_syscalls(uint64_t* kpti_avg_c, uint64_t* nopti_avg_c, char* cpu, char* output_path) {
    PLOT_INIT

    strcat(plot_output_path, "plot-fm_syscalls.pdf");

    //Alle benötigten Werte in Dateien zum plotten schreiben
    double xval = 1; //X-Achsen Positionsindex
    for (int i = 0; i < 3; i++) {
        fprintf(fptr_plotdata_kpti_cycles, "%f %d\n", xval, (int) kpti_avg_c[i]);
        fprintf(fptr_plotdata_nopti_cycles, "%f %d\n", xval += 1, (int) nopti_avg_c[i]);
        fprintf(fptr_plotdata_kpti_ns, "%f %d\n", xval += 1.25, (int) kpti_avg_c[i + 3]);
        fprintf(fptr_plotdata_nopti_ns, "%f %d\n", xval += 1, (int) nopti_avg_c[i + 3]);
        xval += 2;
    }

    PLOT_FILES_CLOSE

    //Y-Achsen Größe bestimmen
    int y_max = 0;
    for (int i = 0; i < 3; i++) {
        if (kpti_avg_c[i] > y_max) y_max = kpti_avg_c[i];
        if (nopti_avg_c[i] > y_max) y_max = nopti_avg_c[i];
    }

    printf("Plot File Management Systemcalls:");
    fflush(stdout);

    //Gnuplot Befehle zum plotten
    snprintf(plot_command, 1800, "set title 'Syscall Ausführungszeiten mit und ohne KPTI auf Intel Prozessor %s'\n"
                                 "set ylabel 'Benötigte CPU-Zykel'\n"
                                 "set yrange[0:%d]\n"
                                 "set xrange[0:15.75]\n"
                                 "set y2tics\n"
                                 "set y2label 'Benötigte Zeit in Nanosekunden'\n"
                                 "set ytics nomirror\n"
                                 "set y2range[0:%d]\n"
                                 "set grid\n"
                                 "set xtics ('Open' 2.75, 'Read ' 8, 'Close' 13.25)\n"
                                 "set boxwidth 0.97\n"
                                 "set style fill solid\n"
                                 "set datafile separator ' '\n"
                                 "plot '%s' using 1:2 with boxes linecolor rgb '#07519A' title 'mit KPTI in Zyklen', "
                                 "'%s' with boxes linecolor rgb '#EAB90C' title 'ohne KPTI in Zyklen',"
                                 "'%s' with boxes linecolor rgb '#5185b8' title 'mit KPTI in ns',"
                                 "'%s' with boxes linecolor rgb '#f0ce55' title 'ohne KPTI in ns'\n"
                                 "set output '%s'\n"
                                 "set term pdfcairo enhanced\n"
                                 "replot\n", cpu, y_max + y_max / 3, y_max + y_max / 3, plotdata_kpti_path_cycles, plotdata_nopti_path_cycles,
                                 plotdata_kpti_path_ns, plotdata_nopti_path_ns, plot_output_path);

    plot(plot_command);

    PLOT_FINI
}

//Bereitet Plot für Fork Systemcall vor und plottet
void plot_fork_syscall(uint64_t* kpti_avg_c, uint64_t* nopti_avg_c, char* cpu, char* output_path) {
    PLOT_INIT

    strcat(plot_output_path, "plot-fork_syscall.pdf");

    //Alle benötigten Werte in Datei zum plotten schreiben

    double xval = 1; //X-Achsen Positionsindex
    int i = 6;
    fprintf(fptr_plotdata_kpti_cycles, "%f %d\n", xval, (int) kpti_avg_c[i]);
    fprintf(fptr_plotdata_nopti_cycles, "%f %d\n", xval += 1, (int) nopti_avg_c[i]);
    fprintf(fptr_plotdata_kpti_ns, "%f %d\n", xval += 1.25, (int) kpti_avg_c[i + 10]);
    fprintf(fptr_plotdata_nopti_ns, "%f %d\n", xval += 1, (int) nopti_avg_c[i + 10]);

    PLOT_FILES_CLOSE

    //Y-Achsen Größe bestimmen
    int y_max = 0;
    if (kpti_avg_c[i] > y_max) y_max = kpti_avg_c[i];
    if (nopti_avg_c[i] > y_max) y_max = nopti_avg_c[i];

    printf("Plot Fork Systemcall:");
    fflush(stdout);

    //Gnuplot Befehle zum plotten
    snprintf(plot_command, 1800, "set title 'Syscall Ausführungszeiten mit und ohne KPTI auf Intel Prozessor %s'\n"
                                 "set ylabel 'Benötigte CPU-Zykel'\n"
                                 "set yrange[0:%d]\n"
                                 "set xrange[0:5.25]\n"
                                 "set y2tics\n"
                                 "set y2label 'Benötigte Zeit in Nanosekunden'\n"
                                 "set ytics nomirror\n"
                                 "set y2range[0:%d]\n"
                                 "set grid\n"
                                 "set xtics ('Fork' 2.75)\n"
                                 "set boxwidth 0.97\n"
                                 "set style fill solid\n"
                                 "set datafile separator ' '\n"
                                 "plot '%s' using 1:2 with boxes linecolor rgb '#07519A' title 'mit KPTI in Zyklen', "
                                 "'%s' with boxes linecolor rgb '#EAB90C' title 'ohne KPTI in Zyklen',"
                                 "'%s' with boxes linecolor rgb '#5185b8' title 'mit KPTI in ns',"
                                 "'%s' with boxes linecolor rgb '#f0ce55' title 'ohne KPTI in ns'\n"
                                 "set output '%s'\n"
                                 "set term pdfcairo enhanced\n"
                                 "replot\n", cpu, y_max + y_max / 3, y_max + y_max / 3, plotdata_kpti_path_cycles,
             plotdata_nopti_path_cycles, plotdata_kpti_path_ns, plotdata_nopti_path_ns, plot_output_path);

    plot(plot_command);

    PLOT_FINI
}

//Bereitet Plot für Process Control Systemcalls vor und plottet
void plot_pc_syscalls(uint64_t* kpti_avg_c, uint64_t* nopti_avg_c, char* cpu, char* output_path) {
    PLOT_INIT

    strcat(plot_output_path, "plot-pc_syscalls.pdf");

    //Alle benötigten Werte in Datei zum plotten schreiben
    double xval = 1; //X-Achsen Positionsindex
    //PC Syscalls ohne fork
    for (int i = 7; i < 16; i++) {
        fprintf(fptr_plotdata_kpti_cycles, "%f %d\n", xval, (int) kpti_avg_c[i]);
        fprintf(fptr_plotdata_nopti_cycles, "%f %d\n", xval += 1, (int) nopti_avg_c[i]);
        fprintf(fptr_plotdata_kpti_ns, "%f %d\n", xval += 1.25, (int) kpti_avg_c[i + 10]);
        fprintf(fptr_plotdata_nopti_ns, "%f %d\n", xval += 1, (int) nopti_avg_c[i + 10]);
        xval += 2;
    }

    PLOT_FILES_CLOSE

    //Y-Achsen Größe bestimmen
    int y_max = 0;
    for (int i = 7; i < 16; i++) {
        if (kpti_avg_c[i] > y_max) y_max = kpti_avg_c[i];
        if (nopti_avg_c[i] > y_max) y_max = nopti_avg_c[i];
    }

    printf("Plot Process Control Systemcalls:");
    fflush(stdout);

    //Gnuplot Befehle zum plotten
    snprintf(plot_command, 1800, "set title 'Syscall Ausführungszeiten mit und ohne KPTI auf Intel Prozessor %s'\n"
                                 "set ylabel 'Benötigte CPU-Zykel'\n"
                                 "set yrange[0:%d]\n"
                                 "set xrange[0:47.25]\n"
                                 "set y2tics\n"
                                 "set y2label 'Benötigte Zeit in Nanosekunden'\n"
                                 "set ytics nomirror\n"
                                 "set y2range[0:%d]\n"
                                 "set grid\n"
                                 "set xtics ('Getpid' 2.75, \"Mmap\\n(1 Byte)\" 8, \"Munmap\\n(1 Byte)\" 13.25, \"Mmap\\n(1 KiB)\" 18.5, \"Munmap\\n(1 KiB)\" 23.75, \"Mmap\\n(1 MiB)\" 29, \"Munmap\\n(1 MiB)\" 34.25, \"Mmap\\n(1 GiB)\" 39.5, \"Munmap\\n(1 GiB)\" 44.75)\n"
                                 "set boxwidth 0.97\n"
                                 "set style fill solid\n"
                                 "set datafile separator ' '\n"
                                 "set bmargin 3\n"
                                 "plot '%s' using 1:2 with boxes linecolor rgb '#07519A' title 'mit KPTI in Zyklen', "
                                 "'%s' with boxes linecolor rgb '#EAB90C' title 'ohne KPTI in Zyklen',"
                                 "'%s' with boxes linecolor rgb '#5185b8' title 'mit KPTI in ns',"
                                 "'%s' with boxes linecolor rgb '#f0ce55' title 'ohne KPTI in ns'\n"
                                 "set output '%s'\n"
                                 "set term pdfcairo size 9in,3in enhanced\n"
                                 "replot\n", cpu, y_max + y_max / 2, y_max + y_max / 2, plotdata_kpti_path_cycles,
             plotdata_nopti_path_cycles, plotdata_kpti_path_ns, plotdata_nopti_path_ns, plot_output_path);

    plot(plot_command);

    PLOT_FINI
}

//Bereitet Plot für Verlust durch Systemcalls in Prozent vor und plottet
void plot_loss_percentage(uint64_t* kpti_avg_c, uint64_t* nopti_avg_c, char* cpu, char* output_path) {
    PLOT_INIT

    strcat(plot_output_path, "plot-syscall_loss_percentage.pdf");

    //Performanceverlust durch KPTI in Prozent berechnen
    double loss_p[NUMBER_OF_CATEGORIES];
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        loss_p[i] = (((double) kpti_avg_c[i] / (double) nopti_avg_c[i]) - 1) * 100;
    }

    //Alle benötigten Werte in Datei zum plotten schreiben
    double xval = 1; //X-Achsen Positionsindex
    //FM Syscalls
    for (int i = 0; i < 3; i++) {
        fprintf(fptr_plotdata_kpti_cycles, "%f %f\n", xval, (double) loss_p[i]);
        fprintf(fptr_plotdata_kpti_ns, "%f %f\n", xval += 1, (double) loss_p[i + 3]);
        xval += 1.5;
    }

    //PC Syscalls
    for (int i = 6; i < 16; i++) {
        fprintf(fptr_plotdata_kpti_cycles, "%f %f\n", xval, (double) loss_p[i]);
        fprintf(fptr_plotdata_kpti_ns, "%f %f\n", xval += 1, (double) loss_p[i + 10]);
        xval += 1.5;
    }

    PLOT_FILES_CLOSE

    //Y-Achsen Größe bestimmen
    int y_max = 0;
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        if (loss_p[i] > y_max) y_max = loss_p[i];
    }
    //Y-Achsen Größe bestimmen (minimum / ggf. negative Werte)
    int y_min = 0;
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        if (loss_p[i] < y_min) y_min = loss_p[i];
    }

    printf("Plot Systemcall KPTI Loss:");
    fflush(stdout);

    //Gnuplot Befehle zum plotten
    snprintf(plot_command, 1800, "set title 'Syscall Ausführungszeitverlust durch KPTI auf Intel Prozessor %s'\n"
                                 "set ylabel 'Verlust in Prozent'\n"
                                 "set yrange[%d:%d]\n"
                                 "set xrange[0:33]\n"
                                 "set grid\n"
                                 "set xtics ('Open' 1.5,'Read' 4,'Close' 6.5,'Fork' 9,'Getpid' 11.5, \"Mmap\\n(1 Byte)\" 14, \"Munmap\\n(1 Byte)\" 16.5, \"Mmap\\n(1 KiB)\" 19, \"Munmap\\n(1 KiB)\" 21.5, \"Mmap\\n(1 MiB)\" 24, \"Munmap\\n(1 MiB)\" 26.5, \"Mmap\\n(1 GiB)\" 29, \"Munmap\\n(1 GiB)\" 31.5)\n"
                                 "set boxwidth 0.97\n"
                                 "set style fill solid\n"
                                 "set datafile separator ' '\n"
                                 "set bmargin 3\n"
                                 "plot '%s' using 1:2 with boxes linecolor rgb '#07519A' title 'CPU Zykel', "
                                 "'%s' with boxes linecolor rgb '#EAB90C' title 'Nanosekunden'\n"
                                 "set output '%s'\n"
                                 "set term pdfcairo size 11in,3in enhanced\n"
                                 "replot\n", cpu, y_min + y_min / 5, y_max + y_max / 3, plotdata_kpti_path_cycles,
             plotdata_kpti_path_ns, plot_output_path);

    plot(plot_command);

    PLOT_FINI

}

//Klassifiziert die Messungen nach Ähnlichkeit zu TLB Hit oder Miss
similarity_t classify_simil_tlb(char* path, uint64_t total_measurements) {
    FILE* fptr;
    uint64_t val[4];
    char* category[4];
    for (int i = 0; i < 4; i++) category[i] = malloc(30 * sizeof(char));
    similarity_t simil;

    uint64_t hit_histogram[HIST_SIZE];
    uint64_t miss_histogram[HIST_SIZE];
    uint64_t measure_histogram[HIST_SIZE];
    uint64_t cmp_hit;       //Zum Zwischenspeichern der Differenz zur eigentlichen Messung als Vergleichswert
    uint64_t cmp_miss;      //Zum Zwischenspeichern der Differenz zur eigentlichen Messung als Vergleichswert

    uint64_t num_hit = 0;           //Anzahl als Hit klassifizierte Messungen
    uint64_t num_miss = 0;          //Anzahl als Miss klassifizierte Messungen

    //Öffnen der Datei mit allen Messungen und zwischenspeichern in Histogramm Arrays
    if ((fptr = fopen(path, "r")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", path);
        exit(1);
    }
    fscanf(fptr, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
    for (int i = 0; i < HIST_SIZE; i++) {
        fscanf(fptr, "%lu %lu %lu %lu\n", &val[0], &val[1], &val[2], &val[3]);
        hit_histogram[i] = val[1];
        miss_histogram[i] = val[2];
        measure_histogram[i] = val[3];
    }
    fclose(fptr);

    //Klassifizierung nach Ähnlichkeit
    for (int i = 0; i < HIST_SIZE - 1; i++) {
        //Differenz pro Zykel Anzahl zwischen Hit bzw. Miss und eigentlicher Messung bestimmen
        cmp_hit = abs((int) hit_histogram[i] - (int) measure_histogram[i]);
        cmp_miss = abs((int) miss_histogram[i] - (int) measure_histogram[i]);

        uint64_t smallest_dif = INT64_MAX;
        int classified = -1;      //1-Hit, 0-Miss

        //Nach kleinerer Differenz als Hit oder Miss klassifizieren
        if (cmp_hit < smallest_dif) {
            smallest_dif = cmp_hit;
            classified = 1;
        }
        if (cmp_miss < smallest_dif) {
            smallest_dif = cmp_miss;
            classified = 0;
        }

        //Anzahl Messungen dieser benötigen Zykel Zeit auf Anzahl Hits bzw. Misses anrechnen
        if (classified == 0) {
            num_miss += measure_histogram[i];
        } else {
            num_hit += measure_histogram[i];
        }
    }

    simil.p_miss = (double) num_miss / (double) total_measurements * 100;
    simil.num_miss = num_miss;

    for (int i = 0; i < 4; i++) free(category[i]);

    return simil;
}

//Bereitet Plot für TLB Messungen je mit und ohne KPTI vor und plottet
void plot_tlb(char* dir_input_path, char* cpu, char* dir_output_path) {
    FILE* fptr_output;
    FILE* fptr_input;
    FILE* fptr_table;

    int val[4];                             // Zum zwischenspeichern der ausgelesenen Werte aus Datei
    similarity_t simil_classif_kpti;        // Zum zwischenspeichern der Werte aus Klassifikation nach Ähnlichkeit
    similarity_t simil_classif_nopti;       // Zum zwischenspeichern der Werte aus Klassifikation nach Ähnlichkeit

    // Variablen zur Bestimmung von Threshold
    uint64_t thresh_kpti = 0;
    uint64_t thresh_nopti = 0;
    uint64_t max_kpti = 0;
    uint64_t max_nopti = 0;
    uint64_t max_both = 0;
    uint64_t hit_max = 0;
    uint64_t hit_most_index = 0;
    uint64_t miss_max = 0;
    uint64_t miss_most_index = 0;
    uint64_t over_thresh_kpti = 0;      //Anzahl von oberhalb von Threshold liegenden Messsungen KPTI
    uint64_t over_thresh_nopti = 0;     //Anzahl von oberhalb von Threshold liegenden Messsungen NOPTI

    uint64_t avg_hit_kpti = 0;          //Durchschnittlich benötigte Zykel für einen TLB Hit KPTI
    uint64_t avg_miss_kpti = 0;         //Durchschnittlich benötigte Zykel für einen TLB Miss KPTI
    uint64_t avg_measure_kpti = 0;      //Durchschnittlich benötigte Zykel für Messung  KPTI
    uint64_t avg_hit_nopti = 0;         //Durchschnittlich benötigte Zykel für einen TLB Hit NOPTI
    uint64_t avg_miss_nopti = 0;        //Durchschnittlich benötigte Zykel für einen TLB Miss NOPTI
    uint64_t avg_measure_nopti = 0;     //Durchschnittlich benötigte Zykel für Messung  NOPTI

    int num_measure_kpti = 0;           //Zählt vorhandene KPTI Durchläufe
    int num_measure_nopti = 0;          //Zählt vorhandene NOPTI Durchläufe
    uint64_t num_measure_single_kpti = 0;     //Zählt gewertete einzel Messungen
    uint64_t num_measure_single_nopti = 0;    //Zählt gewertete einzel Messungen

    //Zum speichern von Messwerten, die nicht eindeutig auf die TLB Belegung zurückzuführen sind und daher ignoriert werden
    uint64_t num_ignore_mes1_nopti = 0;
    uint64_t num_ignore_mes1_kpti = 0;
    uint64_t num_ignore_mes2_nopti = 0;
    uint64_t num_ignore_mes2_kpti = 0;
    uint64_t num_ignore_mes3_nopti = 0;
    uint64_t num_ignore_mes3_kpti = 0;

    int test_size = TLB_TEST_SIZE;      //Anzahl Testadressen
    int ignore_val = 10;                //Untere Schwelle zum Plotten (auf X-Achsen linie keine Darstellung von sehr geringen Werten) -> Plot Übersichtlichkeit

    //Für Infos über PCID Verfügbarkeit
    char* pcid;
#ifndef PCID
    pcid = "PCID: ?";
#else
    if(atoi(PCID)==1)
        pcid="mit PCIDs";
    else
        pcid="ohne PCIDs";
#endif


    char* category[4];
    for (int i = 0; i < 4; i++) category[i] = malloc(30 * sizeof(char));

    char* input_path = malloc(100 * sizeof(char));
    memset(input_path, '\0', 100 * sizeof(char));
    char* text_output_path_kpti = malloc(100 * sizeof(char));
    memset(text_output_path_kpti, '\0', 100 * sizeof(char));
    char* text_output_path_nopti = malloc(100 * sizeof(char));
    memset(text_output_path_nopti, '\0', 100 * sizeof(char));
    char* table_output_path = malloc(100 * sizeof(char));
    memset(table_output_path, '\0', 100 * sizeof(char));

    char* plot_command = malloc(1800 * sizeof(char));
    memset(plot_command, '\0', 1800 * sizeof(char));
    char* plot_output_path_kpti = malloc(100 * sizeof(char));
    memset(plot_output_path_kpti, '\0', 100 * sizeof(char));
    char* plot_output_path_nopti = malloc(100 * sizeof(char));
    memset(plot_output_path_nopti, '\0', 100 * sizeof(char));
    char* plot_output_path_both = malloc(100 * sizeof(char));
    memset(plot_output_path_both, '\0', 100 * sizeof(char));

    //Erstellung von Dateipfaden
    strcpy(text_output_path_kpti, dir_output_path);
    strcat(text_output_path_kpti, F_TLB_AMES_KPTI);
    strcpy(text_output_path_nopti, dir_output_path);
    strcat(text_output_path_nopti, F_TLB_AMES_NOPTI);

    strcpy(plot_output_path_kpti, dir_output_path);
    strcat(plot_output_path_kpti, "plot-tlb_kpti.pdf");
    strcpy(plot_output_path_nopti, dir_output_path);
    strcat(plot_output_path_nopti, "plot-tlb_nopti.pdf");
    strcpy(plot_output_path_both, dir_output_path);
    strcat(plot_output_path_both, "plot-tlb_both.pdf");

    strcpy(table_output_path, dir_output_path);
    strcat(table_output_path, F_TABLE_TLB);


///KPTI Ergebnisse (Max. 5) in eine Datei zusammenführen

    strcpy(input_path, dir_input_path);
    strcat(input_path, F_TLB_KPTI1);

    //Output Datei öffnen und ggf. erzeugen oder überschreiben
    if ((fptr_output = fopen(text_output_path_kpti, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", text_output_path_kpti);
        exit(1);
    }

    if (access(input_path, F_OK) == 0) {  //Datei existiert bereits
        num_measure_kpti++;
        //Input Datei zum lesen öffnen
        if ((fptr_input = fopen(input_path, "r")) == NULL) {
            printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", input_path);
            exit(1);
        }
        //Kategorien einlesen und in Output Datei schreiben
        fscanf(fptr_input, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
        fprintf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);

        //Werte einlesen und in Output Datei schreiben
        for (int i = 0; i < HIST_SIZE; i++) {
            fscanf(fptr_input, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
            fprintf(fptr_output, "%d %d %d %d\n", val[0], val[1], val[2], val[3]);
        }
        fclose(fptr_input);
        fclose(fptr_output);

        //Werte aus verschiedenen messungen in eine Datei zusammenführen
        num_measure_kpti += create_tlb_plotfile(dir_input_path, F_TLB_KPTI2, text_output_path_kpti, category);
        num_measure_kpti += create_tlb_plotfile(dir_input_path, F_TLB_KPTI3, text_output_path_kpti, category);
        num_measure_kpti += create_tlb_plotfile(dir_input_path, F_TLB_KPTI4, text_output_path_kpti, category);
        num_measure_kpti += create_tlb_plotfile(dir_input_path, F_TLB_KPTI5, text_output_path_kpti, category);
    } else {
        printf("Keine Messungen mit KPTI Verfügbar. Bitte nachholen. Beende\n");
        exit(1);
    }


    //KPTI Daten verarbeiten
    if ((fptr_output = fopen(text_output_path_kpti, "r")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", text_output_path_kpti);
        exit(1);
    }
    fscanf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
    //Werte einlesen und Maximum bestimmen
    for (int i = 0; i < HIST_SIZE; i++) {
        fscanf(fptr_output, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
        //Maximum für Plot Y-Achse bestimmen
        for (int k = 1; k < 4; k++) {
            if (val[k] > max_kpti)max_kpti = val[k];
        }
        if (i < HIST_SIZE - 1) {
            //Addieren der Messwerte für Durchschnitt
            for (int m = 0; m < i; m++)avg_hit_kpti += val[1];              //= val[1]*i
            for (int m = 0; m < i; m++)avg_miss_kpti += val[2];             //= val[2]*i
            for (int m = 0; m < i; m++)avg_measure_kpti += val[3];          //= val[3]*i
        } else {
            //Werte auf letztem Histogrammplatz sind nicht auf TLB Belegung, sondern andere Einflüsse zurück zu führen und werden nicht mit einbezogen
            num_ignore_mes1_kpti = val[1];
            num_ignore_mes2_kpti = val[2];
            num_ignore_mes3_kpti = val[3];
        }

    }

    //Durchschnitte bestimmen
    avg_hit_kpti /= ((num_measure_kpti * REP * test_size) - num_ignore_mes1_kpti);
    avg_miss_kpti /= ((num_measure_kpti * REP * test_size) - num_ignore_mes2_kpti);
    avg_measure_kpti /= ((num_measure_kpti * REP * test_size) - num_ignore_mes3_kpti);

    //Anzahl gewertete Gesamtmessungen bestimmen
    num_measure_single_kpti = (num_measure_kpti * REP * test_size) - num_ignore_mes3_kpti;

    //Threshold bestimmen
    rewind(fptr_output);
    fscanf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
    for (int i = 0; i < HIST_SIZE - 1; i++) {
        fscanf(fptr_output, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
        if (val[1] > hit_max) {
            hit_max = val[1];
            hit_most_index = i;
        }
        if (val[2] > miss_max) {
            miss_max = val[2];
            miss_most_index = i;
        }
    }
    thresh_kpti = (hit_most_index + miss_most_index) / 2;


    //Zählung TLB Misses nach Threshold
    rewind(fptr_output);
    fscanf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
    for (int i = 0; i < HIST_SIZE - 1; i++) {
        fscanf(fptr_output, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
        if (i > thresh_kpti) {
            over_thresh_kpti += val[3];
        }
    }
    fclose(fptr_output);

    //Klassifizierung nach Ähnlichkeit
    simil_classif_kpti = classify_simil_tlb(text_output_path_kpti, num_measure_single_kpti);


///NOPTI Ergebnisse (Max. 5) in eine Datei zusammenführen

    strcpy(input_path, dir_input_path);
    strcat(input_path, F_TLB_NOPTI1);

    //Output Datei öffnen und ggf. erzeugen oder überschreiben
    if ((fptr_output = fopen(text_output_path_nopti, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", text_output_path_nopti);
        exit(1);
    }

    if (access(input_path, F_OK) == 0) {  //Datei existiert bereits
        num_measure_nopti++;
        //Input Datei zum lesen öffnen
        if ((fptr_input = fopen(input_path, "r")) == NULL) {
            printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", input_path);
            exit(1);
        }
        //Kategorien einlesen und in Output Datei schreiben
        fscanf(fptr_input, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
        fprintf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);

        //Werte einlesen und in Output Datei schreiben
        for (int i = 0; i < HIST_SIZE; i++) {
            fscanf(fptr_input, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
            fprintf(fptr_output, "%d %d %d %d\n", val[0], val[1], val[2], val[3]);
        }
        fclose(fptr_input);
        fclose(fptr_output);

        num_measure_nopti += create_tlb_plotfile(dir_input_path, F_TLB_NOPTI2, text_output_path_nopti, category);
        num_measure_nopti += create_tlb_plotfile(dir_input_path, F_TLB_NOPTI3, text_output_path_nopti, category);
        num_measure_nopti += create_tlb_plotfile(dir_input_path, F_TLB_NOPTI4, text_output_path_nopti, category);
        num_measure_nopti += create_tlb_plotfile(dir_input_path, F_TLB_NOPTI5, text_output_path_nopti, category);

    } else {
        printf("Keine Messungen ohne KPTI Verfügbar. Bitte nachholen. Beende\n");
        exit(1);
    }

    //NOPTI Daten verarbeiten
    if ((fptr_output = fopen(text_output_path_nopti, "r")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", text_output_path_nopti);
        exit(1);
    }
    fscanf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
    for (int i = 0; i < HIST_SIZE; i++) {
        fscanf(fptr_output, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
        //Maximum für Plot Y-Achse bestimmen
        for (int k = 1; k < 4; k++) {
            if (val[k] > max_nopti)max_nopti = val[k];
        }
        if (i < HIST_SIZE - 1) {
            for (int m = 0; m < i; m++)avg_hit_nopti += val[1];        //= val[1]*i
            for (int m = 0; m < i; m++)avg_miss_nopti += val[2];       //= val[2]*i
            for (int m = 0; m < i; m++)avg_measure_nopti += val[3];    //= val[3]*i
        } else {
            //Werte auf letztem Histogrammplatz sind nicht auf TLB Belegung, sondern andere Einflüsse zurück zu führen und werden nicht mit einbezogen
            num_ignore_mes1_nopti = val[1];
            num_ignore_mes2_nopti = val[2];
            num_ignore_mes3_nopti = val[3];
        }
    }

    //Durchschnitte bestimmen
    avg_hit_nopti /= ((num_measure_nopti * REP * test_size) - num_ignore_mes1_nopti);
    avg_miss_nopti /= ((num_measure_nopti * REP * test_size) - num_ignore_mes2_nopti);
    avg_measure_nopti /= ((num_measure_nopti * REP * test_size) - num_ignore_mes3_nopti);

    //Anzahl gewertete Gesamtmessungen bestimmen
    num_measure_single_nopti = (num_measure_nopti * REP * test_size) - num_ignore_mes3_nopti;

    //Variablen zur Zwischenspeicherung wieder auf initiale Werte setzen
    hit_max = 0;
    hit_most_index = 0;
    miss_max = 0;
    miss_most_index = 0;

    //Threshold bestimmen
    rewind(fptr_output);
    fscanf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
    for (int i = 0; i < HIST_SIZE - 1; i++) {
        fscanf(fptr_output, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
        if (val[1] > hit_max) {
            hit_max = val[1];
            hit_most_index = i;
        }
        if (val[2] > miss_max) {
            miss_max = val[2];
            miss_most_index = i;
        }

    }

    thresh_nopti = (hit_most_index + miss_most_index) / 2;

    //Zählung TLB Misses nach Threshold
    rewind(fptr_output);
    fscanf(fptr_output, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);
    for (int i = 0; i < HIST_SIZE - 1; i++) {
        fscanf(fptr_output, "%d %d %d %d\n", &val[0], &val[1], &val[2], &val[3]);
        if (i > thresh_nopti) {
            over_thresh_nopti += val[3];
        }
    }
    fclose(fptr_output);

    //Klassifizierung nach Ähnlichkeit

    simil_classif_nopti = classify_simil_tlb(text_output_path_nopti, num_measure_single_nopti);


    //Evaluationsergebnisse zusammen auf Konsole ausgeben
    printf("Durchschnittswerte der letzten TLB Messungen für Prozessor %s:\n", cpu);
    printf(".-------------------------------------------------------------------------------------------------------------------------------.\n");
    printf("| %43s |   KPTI (%s)\t|\t   NOPTI  \t|       Verlust durch KPTI  \t|\n", " ", pcid);
    printf("|---------------------------------------------+-------------------------+-----------------------+-------------------------------|\n");
    printf("| %43s | %9lu (%d) \t| %9lu (%d) \t| \t\t-  \t\t|\n", "Gesamt Messungen nach Kontextwechsel",num_measure_single_kpti, num_measure_kpti * REP * test_size, num_measure_single_nopti,num_measure_nopti * REP * test_size);
    printf("| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Durchschnitt TLB Hit", avg_hit_kpti, avg_hit_nopti, (int) avg_hit_kpti - (int) avg_hit_nopti,(((double) avg_hit_kpti / (double) avg_hit_nopti) - 1) * 100);
    printf("| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Durchschnitt TLB Miss", avg_miss_kpti, avg_miss_nopti, (int) avg_miss_kpti - (int) avg_miss_nopti, (((double) avg_miss_kpti / (double) avg_miss_nopti) - 1) * 100);
    printf("| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Durchschnitt Messung", avg_measure_kpti, avg_measure_nopti, (int) avg_measure_kpti - (int) avg_measure_nopti, (((double) avg_measure_kpti / (double) avg_measure_nopti) - 1) * 100);
    printf("|---------------------------------------------+-------------------------+-----------------------+-------------------------------|\n");
    printf("| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Threshold", thresh_kpti, thresh_nopti, (int) thresh_kpti - (int) thresh_nopti, (((double) thresh_kpti / (double) thresh_nopti) - 1) * 100);
    printf("| %43s | %9lu / %5.2f %% \t|  %9lu / %5.2f %%  |  %9d Hits / %6.2f %% \t|\n", "Nach Threshold als TLB Miss klassifiziert", over_thresh_kpti, (double) over_thresh_kpti * 100 / (double) num_measure_single_kpti, over_thresh_nopti, (double) over_thresh_nopti * 100 / (double) num_measure_single_nopti, (int) over_thresh_kpti - (int) over_thresh_nopti, (((double) over_thresh_kpti / (double) over_thresh_nopti) - 1) * 100);
    printf("|---------------------------------------------+-------------------------+-----------------------+-------------------------------|\n");
    printf("| %43s | %9lu / %5.2f %% \t|  %9lu / %5.2f %%  |  %9d Hits / %6.2f %% \t|\n", " TLB Misses nach Ähnlichkeitsklassifikation", simil_classif_kpti.num_miss, simil_classif_kpti.p_miss, simil_classif_nopti.num_miss, simil_classif_nopti.p_miss, (int) simil_classif_kpti.num_miss - (int) simil_classif_nopti.num_miss, (((double) simil_classif_kpti.num_miss / (double) simil_classif_nopti.num_miss) - 1) * 100);
    printf("'-------------------------------------------------------------------------------------------------------------------------------'\n");


    if ((fptr_table = fopen(table_output_path, "w+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s. Evaluationsergebnisse können nicht zusätzlich gespeichert werden\e[39;0m\n",
               table_output_path);
    } else {
        printf("\nDiese Ausgabe befindet sich nun in '%s'\n", table_output_path);
    }

    //Ergebnisse auch in Datei
    fprintf(fptr_table, "Durchschnittswerte der letzten TLB Messungen für Prozessor %s:\n", cpu);
    fprintf(fptr_table,".-------------------------------------------------------------------------------------------------------------------------------.\n");
    fprintf(fptr_table, "| %43s |   KPTI (%s)\t|\t   NOPTI  \t|       Verlust durch KPTI  \t|\n", " ", pcid);
    fprintf(fptr_table,"|---------------------------------------------+-------------------------+-----------------------+-------------------------------|\n");
    fprintf(fptr_table, "| %43s | %9lu (%d) \t| %9lu (%d) \t| \t\t-  \t\t|\n", "Gesamt Messungen nach Kontextwechsel", num_measure_single_kpti, num_measure_kpti * REP * test_size, num_measure_single_nopti, num_measure_nopti * REP * test_size);
    fprintf(fptr_table, "| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Durchschnitt TLB Hit", avg_hit_kpti, avg_hit_nopti, (int) avg_hit_kpti - (int) avg_hit_nopti, (((double) avg_hit_kpti / (double) avg_hit_nopti) - 1) * 100);
    fprintf(fptr_table, "| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Durchschnitt TLB Miss", avg_miss_kpti, avg_miss_nopti, (int) avg_miss_kpti - (int) avg_miss_nopti, (((double) avg_miss_kpti / (double) avg_miss_nopti) - 1) * 100);
    fprintf(fptr_table, "| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Durchschnitt Messung", avg_measure_kpti, avg_measure_nopti, (int) avg_measure_kpti - (int) avg_measure_nopti, (((double) avg_measure_kpti / (double) avg_measure_nopti) - 1) * 100);
    fprintf(fptr_table,"|---------------------------------------------+-------------------------+-----------------------+-------------------------------|\n");
    fprintf(fptr_table, "| %43s | \t%lu Zykel \t|\t%lu Zykel \t|     %3d Zykel / %6.2f %%\t|\n", "Threshold", thresh_kpti, thresh_nopti, (int) thresh_kpti - (int) thresh_nopti, (((double) thresh_kpti / (double) thresh_nopti) - 1) * 100);
    fprintf(fptr_table, "| %43s | %9lu / %5.2f %% \t|  %9lu / %5.2f %%  |  %9d Hits / %6.2f %% \t|\n", "Nach Threshold als TLB Miss klassifiziert", over_thresh_kpti, (double) over_thresh_kpti * 100 / (double) num_measure_single_kpti, over_thresh_nopti, (double) over_thresh_nopti * 100 / (double) num_measure_single_nopti, (int) over_thresh_kpti - (int) over_thresh_nopti,(((double) over_thresh_kpti / (double) over_thresh_nopti) - 1) * 100);
    fprintf(fptr_table,"|---------------------------------------------+-------------------------+-----------------------+-------------------------------|\n");
    fprintf(fptr_table, "| %43s | %9lu / %5.2f %% \t|  %9lu / %5.2f %%  |  %9d Hits / %6.2f %% \t|\n", " TLB Misses nach Ähnlichkeitsklassifikation", simil_classif_kpti.num_miss, simil_classif_kpti.p_miss, simil_classif_nopti.num_miss, simil_classif_nopti.p_miss, (int) simil_classif_kpti.num_miss - (int) simil_classif_nopti.num_miss, (((double) simil_classif_kpti.num_miss / (double) simil_classif_nopti.num_miss) - 1) * 100);
    fprintf(fptr_table,"'-------------------------------------------------------------------------------------------------------------------------------'\n");
    fclose(fptr_table);

    if ((num_measure_kpti * REP * test_size) != (num_measure_nopti * REP * test_size))
        printf("\e[31;1mAchtung: Es wurden unterschiedlich viele Analyse Durchläufe mit und ohne KPTI getätigt. Dies kann zu fehlerhaften Vergleichswerten führen.\e[39;0m\n");

    printf("\nPlot TLB Messungen KPTI:");
    fflush(stdout);

    //Plot KPTI Ergebnisse
    snprintf(plot_command, 1800, "set title 'TLB Messungen mit KPTI auf Intel Prozessor %s'\n"
                                 "set xlabel 'benötigte CPU-Zykel'\n"
                                 "set ylabel 'absolute Häufigkeit'\n"
                                 "set grid\n" "set xrange[0:%d]\n"
                                 "set yrange[0:%lu]\n"
                                 "set xtics 25\n"
                                 "set arrow from %lu,0 to %lu,%lu nohead\n"             //Berechneten Wert für Threshold als vertikale Linie zeichnen
                                 "set label ' Threshold: %lu' at %lu,%lu\n"
                                 "plot '%s' using 1:($2 > %d ? $2 : 1/0) pointtype 9 linecolor rgb 'green' title 'TLB Hit', "          //TLB Hit Graph
                                 "'%s' using 1:($3 > %d ? $3 : 1/0) pointtype 11 linecolor rgb 'red' title 'TLB Miss', "             //TLB Miss Graph
                                 "'%s' using 1:($4 > %d ? $4 : 1/0) pointtype 12 linecolor rgb '#07519A' title 'Nach Kontextwechsel'\n"     //Eigentliche Messung
                                 "set term pdfcairo enhanced\n"
                                 "set output '%s'\n"
                                 "replot\n", cpu, HIST_SIZE - 2, max_kpti + max_kpti / 3, thresh_kpti, thresh_kpti,
             max_kpti + max_kpti / 3, thresh_kpti, thresh_kpti, max_kpti - max_kpti / 4,
             text_output_path_kpti, ignore_val, text_output_path_kpti, ignore_val, text_output_path_kpti, ignore_val,
             plot_output_path_kpti);
    plot(plot_command);


    printf("Plot TLB Messungen NOPTI:");
    fflush(stdout);

    //Plot NOPTI Ergebnisse
    snprintf(plot_command, 1800, "set title 'TLB Messungen ohne KPTI auf Intel Prozessor %s'\n"
                                 "set xlabel 'benötigte CPU-Zykel'\n"
                                 "set ylabel 'absolute Häufigkeit'\n"
                                 "set grid\n" "set xrange[0:%d]\n"
                                 "set yrange[0:%lu]\n"
                                 "set xtics 25\n"
                                 "set arrow from %lu,0 to %lu,%lu nohead\n"             //Berechneten Wert für Threshold als vertikale Linie zeichnen
                                 "set label ' Threshold: %lu' at %lu,%lu\n"
                                 "plot '%s' using 1:($2 > %d ? $2 : 1/0) pointtype 9 linecolor rgb 'green' title 'TLB Hit', "          //TLB Hit Graph
                                 "'%s' using 1:($3 > %d ? $3 : 1/0) pointtype 11 linecolor rgb 'red' title 'TLB Miss', "             //TLB Miss Graph
                                 "'%s' using 1:($4 > %d ? $4 : 1/0) pointtype 12 linecolor rgb '#07519A' title 'Nach Kontextwechsel'\n"     //Eigentliche Messung
                                 "set term pdfcairo enhanced\n"
                                 "set output '%s'\n"
                                 "replot\n", cpu, HIST_SIZE - 2, max_nopti + max_nopti / 3, thresh_nopti, thresh_nopti,
             max_nopti + max_nopti / 3, thresh_nopti, thresh_nopti, max_nopti - max_nopti / 4,
             text_output_path_nopti, ignore_val, text_output_path_nopti, ignore_val, text_output_path_nopti, ignore_val,
             plot_output_path_nopti);
    plot(plot_command);


    if (max_nopti > max_kpti) max_both = max_nopti;
    else max_both = max_kpti;


    printf("Plot TLB Messungen KPTI & NOPTI:");
    fflush(stdout);

    //Plot NOPTI Ergebnisse
    snprintf(plot_command, 1800, "set title 'TLB Messungen mit und ohne KPTI im Vergleich auf Intel Prozessor %s'\n"
                                 "set xlabel 'benötigte CPU-Zykel'\n"
                                 "set ylabel 'absolute Häufigkeit'\n"
                                 "set grid\n" "set xrange[0:%d]\n"
                                 "set yrange[0:%lu]\n"
                                 "set xtics 25\n"
                                 "set arrow from %lu,0 to %lu,%lu nohead linecolor rgb 'green' \n"             //Berechneten Wert für Threshold als vertikale Linie zeichnen
                                 "set label ' Threshold NOPTI' at %lu,%lu textcolor rgb 'green' \n"
                                 "set arrow from %lu,0 to %lu,%lu nohead linecolor rgb 'red' \n"             //Berechneten Wert für Threshold als vertikale Linie zeichnen
                                 "set label ' Threshold KPTI' at %lu,%lu textcolor rgb 'red' \n"
                                 "plot '%s' using 1:($4 > %d ? $4 : 1/0) pointtype 12 linecolor rgb 'green' title 'Nach Kontextwechsel NOPTI', "
                                 "'%s' using 1:($4 > %d ? $4 : 1/0) pointtype 12 linecolor rgb 'red' title 'Nach Kontextwechsel KPTI'\n"
                                 "set term pdfcairo enhanced\n"
                                 "set output '%s'\n"
                                 "replot\n", cpu, HIST_SIZE - 2, max_both + max_both / 3, thresh_nopti, thresh_nopti,
             max_both + max_both / 3, thresh_nopti, max_both - max_both / 6, thresh_kpti, thresh_kpti,
             max_both + max_both / 3, thresh_kpti, max_both - max_both / 4,
             text_output_path_nopti, ignore_val, text_output_path_kpti, ignore_val, plot_output_path_both);

    plot(plot_command);

    //Speicher freigeben
    free(input_path);
    free(text_output_path_kpti);
    free(text_output_path_nopti);
    free(table_output_path);
    free(plot_command);
    free(plot_output_path_kpti);
    free(plot_output_path_nopti);
    free(plot_output_path_both);

    for (int i = 0; i < 4; i++) free(category[i]);
}


int create_tlb_plotfile(char* dir_input_path, char* file,char* output_path, char** category) {
    FILE* fptr_output;
    FILE* fptr_input;
    FILE* fptr_tmp;

    char* line = NULL;
    size_t len;
    uint64_t val_in[4];
    uint64_t val_out[4];
    uint64_t sum[3];

    char* input_path = malloc(100 * sizeof(char));
    memset(input_path, '\0', 100 * sizeof(char));
    char* tmp_output_path = malloc(100 * sizeof(char));
    memset(input_path, '\0', 100 * sizeof(char));

    strcpy(input_path, dir_input_path);
    strcat(input_path, file);
    strcpy(tmp_output_path, output_path);
    strcat(tmp_output_path, "_TMP");


    if (access(input_path, F_OK) == 0) { //Datei existiert bereits
        //Output Datei öffnen
        if ((fptr_output = fopen(output_path, "r")) == NULL) {
            printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", output_path);
            exit(1);
        }
        //TMP Datei öffnen
        if ((fptr_tmp = fopen(tmp_output_path, "wb")) == NULL) {
            printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", tmp_output_path);
            exit(1);
        }
        //Input Datei zum lesen öffnen
        if ((fptr_input = fopen(input_path, "r")) == NULL) {
            printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", input_path);
            exit(1);
        }

        getline(&line, &len, fptr_output); //Zeile mit Kategorien überpsringen
        getline(&line, &len, fptr_input); //Zeile mit Kategorien überpsringen
        fprintf(fptr_tmp, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);

        //Werte einlesen, verrechnen und in Output Datei schreiben
        for (int i = 0; i < HIST_SIZE; i++) {
            fscanf(fptr_input, "%lu %lu %lu %lu\n", &val_in[0], &val_in[1], &val_in[2], &val_in[3]);
            fscanf(fptr_output, "%lu %lu %lu %lu\n", &val_out[0], &val_out[1], &val_out[2], &val_out[3]);
            sum[0] = val_in[1] + val_out[1];
            sum[1] = val_in[2] + val_out[2];
            sum[2] = val_in[3] + val_out[3];
            fprintf(fptr_tmp, "%lu %lu %lu %lu\n", val_out[0], sum[0], sum[1], sum[2]);
        }
        fclose(fptr_input);
        fclose(fptr_output);
        fclose(fptr_tmp);

        rename(tmp_output_path, output_path);
        remove(tmp_output_path);

        free(input_path);
        free(tmp_output_path);
        free(line);

        return 1;
    } else { //Datei Existiert nicht
        free(input_path);
        free(tmp_output_path);
        free(line);
        return 0;
    }
}



int main() {
    FILE* fptr_eval_single;
    FILE* fptr_dat;

    char* dir = malloc(100 * sizeof(char));
    memset(dir, '\0', 100 * sizeof(char));
    char* sysc_kpti_path = malloc(100 * sizeof(char));
    memset(sysc_kpti_path, '\0', 100 * sizeof(char));
    char* sysc_nopti_path = malloc(100 * sizeof(char));
    memset(sysc_nopti_path, '\0', 100 * sizeof(char));
    char* tlb_path = malloc(100 * sizeof(char));
    memset(tlb_path, '\0', 100 * sizeof(char));
    char* cpu = malloc(20 * sizeof(char));
    memset(cpu, '\0', 20 * sizeof(char));
    char* output_path = malloc(100 * sizeof(char));
    memset(output_path, '\0', 100 * sizeof(char));
    char* table_path = malloc(100 * sizeof(char));
    memset(table_path, '\0', 100 * sizeof(char));

    char* einheit;        //ns oder Zykel, für Tabellen Ausgabe
    char* category[NUMBER_OF_CATEGORIES];
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) category[i] = malloc(20 * sizeof(char));
    uint64_t* kpti_avg_c;
    uint64_t* nopti_avg_c;
    int kpti_da = 1;
    int nopti_da = 1;


    //Dateipfade erstellen
#ifdef CPU_SHORTNAME
    strcpy(cpu,CPU_SHORTNAME);
#else
    printf("Konnte Dateipfade nicht automatisiert konstruieren. Beende.\n");
    exit(1);
#endif
    strcat(dir, "./results/");
    strcat(dir, cpu);
    strcpy(sysc_kpti_path, dir);
    strcat(sysc_kpti_path, "/measurements-syscalls/");
    strcat(sysc_kpti_path, F_AVG_KPTI);
    strcat(sysc_nopti_path, dir);
    strcat(sysc_nopti_path, "/measurements-syscalls/");
    strcat(sysc_nopti_path, F_AVG_NOPTI);
    strcpy(tlb_path, dir);
    strcat(tlb_path, "/measurements-tlb/");


    strcpy(output_path, dir);
    strcat(output_path, "/eval/");

    //Neues Verzeichnis zur Ablage von Evaluationsdaten erstellen, falls noch nicht vorhanden
    struct stat st = {0};
    if (stat(output_path, &st) == -1) mkdir(output_path, 0777);

    strcpy(table_path, output_path);
    strcat(table_path, F_TABLE_SYSC);




/**Daten verarbeiten**/
    //Durchschnitt der KPTI Messungen berechnen
    kpti_avg_c = avg(sysc_kpti_path);
    if (kpti_avg_c[0] == '\0') {
        kpti_da = 0;
        printf("\e[31mVermutlich wurde die Messung mit aktivierter KPTI noch nicht durchgeführt. Bitte nachholen.\e[39m\n\n");
    }
    //Durchschnitt der NOPTI Messungen berechnen
    nopti_avg_c = avg(sysc_nopti_path);
    if (nopti_avg_c[0] == '\0') {
        nopti_da = 0;
        printf("\e[31mVermutlich wurde die Messung ohne KPTI noch nicht durchgeführt. Bitte nachholen.\e[39m\n\n");
    }

    if (kpti_da) {
        //Datei öffnen
        if ((fptr_dat = fopen(sysc_kpti_path, "r")) == NULL) {
            printf("\e[31mFehler beim Öffnen der Datei %s.\e[39m\n\n", sysc_kpti_path);
        }
        READ_CATEGORIES_ALL(fptr_dat)
        fclose(fptr_dat);
    }

    if (nopti_da) {
        //Datei öffnen
        if ((fptr_dat = fopen(sysc_nopti_path, "r")) == NULL) {
            printf("\e[31mFehler beim Öffnen der Datei %s. Vermutlich wurde die Messung ohne KPTI noch nicht durchgeführt. Bitte nachholen.\e[39m\n\n",
                   sysc_nopti_path);
        }
        READ_CATEGORIES_ALL(fptr_dat)
        fclose(fptr_dat);
    }

    printf("--------------------\nMessung Systemcalls:\n--------------------\n\n");


    //Evaluationsergebnisse ausgeben
    printf("Durchschnittswerte der letzten Systemcall Messungen für Prozessor %s:\n", cpu);
    printf(".--------------------------------------------------------------------------------.\n");
    printf("|\t\t\t|      KPTI  \t|     NOPTI  \t|   Performanceverlust\t |\n");
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        printf("|-----------------------+---------------+---------------+------------------------|\n");
        if (i == 3 || i == 4 || i == 5 || i > 15)einheit = "ns   ";
        else einheit = "Zykel";
        printf("| %20s\t|  %8lu \t|  %8lu \t| %5d %s / %6.2f %% |\n", category[i], kpti_avg_c[i], nopti_avg_c[i],
               (int) kpti_avg_c[i] - (int) nopti_avg_c[i], einheit,
               (((double) kpti_avg_c[i] / (double) nopti_avg_c[i]) - 1) * 100);
    }
    printf("'--------------------------------------------------------------------------------'\n");

    //Evaluationsergebnisse übersichtlich in Datei
    if ((fptr_eval_single = fopen(table_path, "w+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s. Evaluationsergebnisse können nicht zusätzlich gespeichert werden\e[39;0m\n",
               table_path);
    } else {
        printf("\nDiese Ausgabe befindet sich nun in '%s'\n\n", table_path);
    }
    fprintf(fptr_eval_single, "Durchschnittswerte der letzten Systemcall Messungen für Prozessor %s:\n", cpu);
    fprintf(fptr_eval_single, ".--------------------------------------------------------------------------------.\n");
    fprintf(fptr_eval_single, "|\t\t\t|      KPTI  \t|     NOPTI  \t|   Performanceverlust\t |\n");
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        fprintf(fptr_eval_single,
                "|-----------------------+---------------+---------------+------------------------|\n");
        if (i == 3 || i == 4 || i == 5 || i > 15)einheit = "ns   ";
        else einheit = "Zykel";
        fprintf(fptr_eval_single, "| %20s\t|  %8lu \t|  %8lu \t| %5d %s / %6.2f %% |\n", category[i], kpti_avg_c[i],
                nopti_avg_c[i], (int) kpti_avg_c[i] - (int) nopti_avg_c[i], einheit,
                (((double) kpti_avg_c[i] / (double) nopti_avg_c[i]) - 1) * 100);
    }
    fprintf(fptr_eval_single, "'--------------------------------------------------------------------------------'\n");
    fclose(fptr_eval_single);


    plot_fm_syscalls(kpti_avg_c, nopti_avg_c, cpu, output_path);
    plot_pc_syscalls(kpti_avg_c, nopti_avg_c, cpu, output_path);
    plot_fork_syscall(kpti_avg_c, nopti_avg_c, cpu, output_path);
    plot_loss_percentage(kpti_avg_c, nopti_avg_c, cpu, output_path);

    printf("\n---------------------\nMessung TLB Belegung:\n---------------------\n\n");
    plot_tlb(tlb_path, cpu, output_path);

    printf("Berechne Varianz und Standardabweichung...\n");
    calc_statistics(dir);
    printf("Informationen zu Varianz und Standardabweichung sind in '%s/eval/statistics/' zu finden.\n", dir);

    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        free(category[i]);
    }
    free(kpti_avg_c);
    free(nopti_avg_c);

    free(dir);
    free(tlb_path);
    free(output_path);
    free(table_path);
    free(sysc_kpti_path);
    free(sysc_nopti_path);
    free(cpu);

}
