#ifndef STATISTICS_H
#define STATISTICS_H


//Konvertiert als Histogramm gespeicherte Daten in einzelne Messungen
uint64_t convert_tlb_measurements(char *path_input, char *path_output) {
    FILE *fptr_input;
    FILE *fptr_output;
    FILE *fptr_hit;
    FILE *fptr_miss;
    FILE *fptr_measure;

    int retval1;
    int retval2;
    int retval3;

    uint64_t num_lines = 0;

    uint64_t val[4];
    char *category[4];
    for (int i = 0; i < 4; i++) {
        category[i] = malloc(30 * sizeof(char));
    }

    char *output_file_hit = "tlb-data_long_hit.csv";
    char *output_file_miss = "tlb-data_long_miss.csv";
    char *output_file_measure = "tlb-data_long_measure.csv";

    //Dateien öffnen
    if ((fptr_input = fopen(path_input, "r")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", path_input);
    }
    if ((fptr_hit = fopen(output_file_hit, "w+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", output_file_hit);
        exit(1);
    }
    if ((fptr_miss = fopen(output_file_miss, "w+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", output_file_miss);
        exit(1);
    }
    if ((fptr_measure = fopen(output_file_measure, "w+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", output_file_measure);
        exit(1);
    }

    //Kategorien auslesen
    fscanf(fptr_input, "%s %s %s %s\n", category[0], category[1], category[2], category[3]);

    //Wandelt Histogramm in einzelne Messungen um und schreibt ergebnisse je Kategorie in Datei
    for (int i = 0; i < HIST_SIZE; i++) {
        fscanf(fptr_input, "%lu %lu %lu %lu\n", &val[0], &val[1], &val[2], &val[3]);
        while (val[1] > 0) {
            fprintf(fptr_hit, "%lu\n", val[0]);
            val[1]--;
        }
        while (val[2] > 0) {
            fprintf(fptr_miss, "%lu\n", val[0]);
            val[2]--;
        }
        while (val[3] > 0) {
            fprintf(fptr_measure, "%lu\n", val[0]);
            val[3]--;
            num_lines++;    //Zählt Anzahl einzelner Messungen. Anzahl für Hits, Misses und Messungen gleich
        }

    }

    //Daten zusammenführen in eine gemeinsame Datei

    //Filepointer auf Anfang der Datei zurück setzen
    rewind(fptr_hit);
    rewind(fptr_miss);
    rewind(fptr_measure);

    if ((fptr_output = fopen(path_output, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s.\e[39;0m\n", path_output);
    }
    fprintf(fptr_output, "%s %s %s\n", category[1], category[2], category[3]);

    //Ergebnisse aus einzelnen Dateien einlesen und in einer Datei zusammenführen
    do {
        retval1 = fscanf(fptr_hit, "%lu\n", &val[1]);
        retval2 = fscanf(fptr_miss, "%lu\n", &val[2]);
        retval3 = fscanf(fptr_measure, "%lu\n", &val[3]);
        fprintf(fptr_output, "%lu %lu %lu\n", val[1], val[2], val[3]);
    } while (retval1 != EOF && retval2 != EOF && retval3 != EOF);


    //Dateien schließen, Temporäre Dateien löschen und Speicher freigeben
    fclose(fptr_input);
    fclose(fptr_output);
    fclose(fptr_hit);
    fclose(fptr_miss);
    fclose(fptr_measure);

    remove(output_file_hit);
    remove(output_file_miss);
    remove(output_file_measure);

    for (int i = 0; i < 4; i++) free(category[i]);

    return num_lines;
}

//Berechnet Varianz und Standardabweichung für TLB Messungen
void calc_statistics_tlb(char *path_input, uint64_t num_lines, char *path_output) {
    FILE* fptr_input;
    FILE* fptr_output;

    char* category[3];
    for (int i = 0; i < 3; i++) category[i] = malloc(20 * sizeof(char));

    uint64_t val[3];
    uint64_t *cur_vals = malloc(num_lines * sizeof(uint64_t));
    double variance[3];
    double std_deviation[3];

    if ((fptr_input = fopen(path_input, "r")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", path_input);
        exit(1);
    }

    //Daten auslesen
    for (int i = 0; i < 3; i++) {
        double avg = 0;
        rewind(fptr_input);
        fscanf(fptr_input, "%s %s %s\n", category[0], category[1], category[2]);
        for (int k = 0; k < num_lines; k++) {
            fscanf(fptr_input, "%lu %lu %lu\n", &val[0], &val[1], &val[2]);
            avg += val[i];
            cur_vals[k] = val[i];       //Alle Werte einer Kategorie zwischenspeichern
        }
        avg /= num_lines;

        //Berechnen von Varianz und Standardabweichung
        variance[i] = 0;
        for (int k = 0; k < num_lines; k++) {
            variance[i] += pow((cur_vals[k] - avg), 2);
        }
        variance[i] /= num_lines;
        std_deviation[i] = sqrt(variance[i]);
    }

    //Daten in Datei schreiben
    if ((fptr_output = fopen(path_output, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", path_output);
        exit(1);
    }
    fprintf(fptr_output, "Kategorie Varianz Standardabweichung\n");
    for (int i = 0; i < 3; i++) {
        fprintf(fptr_output, "%s %.2f %.2f\n", category[i], variance[i], std_deviation[i]);
    }

    //Speicher freigeben und Dateien schließen
    for (int i = 0; i < 3; i++) free(category[i]);
    free(cur_vals);

    fclose(fptr_input);
    fclose(fptr_output);

    remove(path_input);
}


//Berechnet Varianz und Standardabweichung für Systemcall Messungen
void calc_statistics_sysc(char* path_input, int num_lines, char* path_output) {
    FILE* fptr_input;
    FILE* fptr_output;

    char* category[NUMBER_OF_CATEGORIES];
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        category[i] = malloc(20 * sizeof(char));
    }
    uint64_t val[NUMBER_OF_CATEGORIES];
    uint64_t cur_vals[num_lines];
    double variance[NUMBER_OF_CATEGORIES];
    double std_deviation[NUMBER_OF_CATEGORIES];


    //Daten auslesen
    if ((fptr_input = fopen(path_input, "r")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", path_input);
        exit(1);
    }
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        double avg = 0;
        rewind(fptr_input);
        READ_CATEGORIES_ALL(fptr_input)
        for (int k = 0; k < num_lines; k++) {
            fscanf(fptr_input,
                   "%lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n",
                   &val[0], &val[1], &val[2], &val[3], &val[4], &val[5], &val[6], &val[7], &val[8], &val[9], &val[10],
                   &val[11], &val[12], &val[13], &val[14], &val[15], &val[16], &val[17], &val[18], &val[19], &val[20],
                   &val[21], &val[22], &val[23], &val[24], &val[25]);
            avg += val[i];
            cur_vals[k] = val[i]; //Alle Werte einer Kategorie zwischenspeichern
        }
        avg /= num_lines;

        //Berechnen von Varianz und Standardabweichung
        variance[i] = 0;
        for (int k = 0; k < num_lines; k++) {
            variance[i] += pow((cur_vals[k] - avg), 2);
        }
        variance[i] /= num_lines;
        std_deviation[i] = sqrt(variance[i]);
    }

    //Daten in Datei schreiben
    if ((fptr_output = fopen(path_output, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", path_output);
        exit(1);
    }
    fprintf(fptr_output, "Kategorie Varianz Standardabweichung\n");
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        fprintf(fptr_output, "%s %.2f %.2f\n", category[i], variance[i], std_deviation[i]);
    }

    //Speicher freigeben und schließen
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        free(category[i]);
    }
    fclose(fptr_input);
    fclose(fptr_output);
}

//Bereitet Berechnung von Varianz und Standardabweichung für Systemcall und TLB Messungen vor
void calc_statistics(char* dir) {
    uint64_t tlb_lines;

    char* input_path_dir = malloc(100 * sizeof(char));
    memset(input_path_dir, '\0', 100 * sizeof(char));
    strcpy(input_path_dir, dir);
    strcat(input_path_dir, "/measurements-syscalls/");


    char* output_path_dir = malloc(100 * sizeof(char));
    memset(output_path_dir, '\0', 100 * sizeof(char));
    strcpy(output_path_dir, dir);
    strcat(output_path_dir, "/eval/statistics/");

    struct stat st = {0};
    if (stat(output_path_dir, &st) == -1) mkdir(output_path_dir, 0777);

    char* input_path = malloc(100 * sizeof(char));
    memset(input_path, '\0', 100 * sizeof(char));
    char* output_path = malloc(100 * sizeof(char));
    memset(output_path, '\0', 100 * sizeof(char));

    strcpy(input_path, input_path_dir);
    strcat(input_path, F_ANALYSE_KPTI);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "statistics_sysc_single_measurement_kpti.csv");
    calc_statistics_sysc(input_path, NUMBER_OF_CATEGORIES, output_path);

    strcpy(input_path, input_path_dir);
    strcat(input_path, F_ANALYSE_NOPTI);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "statistics_sysc_single_measurement_nopti.csv");
    calc_statistics_sysc(input_path, NUMBER_OF_CATEGORIES, output_path);

    strcpy(input_path, input_path_dir);
    strcat(input_path, F_AVG_KPTI);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "statistics_sysc_avg5_kpti.csv");
    calc_statistics_sysc(input_path, 5, output_path);

    strcpy(input_path, input_path_dir);
    strcat(input_path, F_AVG_NOPTI);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "statistics_sysc_avg5_nopti.csv");
    calc_statistics_sysc(input_path, 5, output_path);

    //TLB KPTI
    strcpy(input_path_dir, dir);
    strcat(input_path_dir, "/eval/");

    strcpy(input_path, input_path_dir);
    strcat(input_path, F_TLB_AMES_KPTI);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "tlb_all_kpti.csv");
    tlb_lines = convert_tlb_measurements(input_path, output_path);

    strcpy(input_path, output_path);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "statistics_tlb_kpti.csv");
    calc_statistics_tlb(input_path, tlb_lines, output_path);

    //TLB NOPTI
    strcpy(input_path, input_path_dir);
    strcat(input_path, F_TLB_AMES_NOPTI);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "tlb_all_nopti.csv");
    tlb_lines = convert_tlb_measurements(input_path, output_path);

    strcpy(input_path, output_path);
    strcpy(output_path, output_path_dir);
    strcat(output_path, "statistics_tlb_nopti.csv");
    calc_statistics_tlb(input_path, tlb_lines, output_path);

    free(input_path);
    free(output_path);
    free(input_path_dir);
    free(output_path_dir);

}


#endif