#ifndef PLOT
#define PLOT


#define F_TABLE_SYSC "table_syscall_measurements.txt"
#define F_TABLE_TLB "table_tlb_measurements.txt"
#define F_TLB_AMES_KPTI "tlb_measurements_kpti.csv"
#define F_TLB_AMES_NOPTI "tlb_measurements_nopti.csv"

typedef struct similarity {
	uint64_t num_miss;
	double p_miss;
} similarity_t;

#define PLOT_INIT \
FILE* fptr_plotdata_kpti_cycles; \
FILE* fptr_plotdata_nopti_cycles;\
FILE* fptr_plotdata_kpti_ns;\
FILE* fptr_plotdata_nopti_ns;\
char* plot_command = malloc(1800*sizeof(char));\
memset(plot_command,'\0',1800*sizeof(char));   \
char* plot_output_path = malloc(100*sizeof(char));\
memset(plot_output_path,'\0',100*sizeof(char));\
char* plotdata_kpti_path_cycles = malloc(100*sizeof(char));\
memset(plotdata_kpti_path_cycles,'\0',100*sizeof(char));\
char* plotdata_nopti_path_cycles = malloc(100*sizeof(char));\
memset(plotdata_nopti_path_cycles,'\0',100*sizeof(char));\
char* plotdata_kpti_path_ns = malloc(100*sizeof(char));\
memset(plotdata_kpti_path_ns,'\0',100*sizeof(char));\
char* plotdata_nopti_path_ns = malloc(100*sizeof(char));\
memset(plotdata_nopti_path_ns,'\0',100*sizeof(char));      \
strcpy(plot_output_path,output_path);                  \
strcpy(plotdata_kpti_path_cycles,output_path);\
strcpy(plotdata_nopti_path_cycles,output_path);\
strcpy(plotdata_kpti_path_ns,output_path);\
strcpy(plotdata_nopti_path_ns,output_path);\
strcat(plotdata_kpti_path_cycles,"plotdata_kpti_cycles.dat");\
strcat(plotdata_nopti_path_cycles,"plotdata_nopti_cycles.dat");\
strcat(plotdata_kpti_path_ns,"plotdata_kpti_nanoseconds.dat");\
strcat(plotdata_nopti_path_ns,"plotdata_nopti_nanoseconds.dat");\
if ((fptr_plotdata_kpti_cycles = fopen(plotdata_kpti_path_cycles, "w+")) == NULL) {\
printf("\e[31;1mFehler beim Öffnen der Datei '%s': %d\e[39;0m\n",plotdata_kpti_path_cycles, errno);\
exit(1);\
}\
if ((fptr_plotdata_nopti_cycles = fopen(plotdata_nopti_path_cycles, "w+")) == NULL) {\
printf("\e[31;1mFehler beim Öffnen der Datei '%s': %d\e[39;0m\n",plotdata_nopti_path_cycles, errno);\
exit(1);\
}\
if ((fptr_plotdata_kpti_ns = fopen(plotdata_kpti_path_ns, "w+")) == NULL) {\
printf("\e[31;1mFehler beim Öffnen der Datei '%s': %d\e[39;0m\n",plotdata_kpti_path_ns, errno);\
exit(1);\
}\
if ((fptr_plotdata_nopti_ns = fopen(plotdata_nopti_path_ns, "w+")) == NULL) {\
printf("\e[31;1mFehler beim Öffnen der Datei '%s': %d\e[39;0m\n",plotdata_nopti_path_ns, errno);\
exit(1);\
}

#define PLOT_FILES_CLOSE \
fclose(fptr_plotdata_kpti_cycles);\
fclose(fptr_plotdata_nopti_cycles);\
fclose(fptr_plotdata_kpti_ns);\
fclose(fptr_plotdata_nopti_ns);

#define PLOT_FINI \
remove(plotdata_kpti_path_cycles);\
remove(plotdata_nopti_path_cycles);\
remove(plotdata_kpti_path_ns);\
remove(plotdata_nopti_path_ns);\
free(plotdata_kpti_path_cycles);\
free(plotdata_nopti_path_cycles);\
free(plotdata_kpti_path_ns);\
free(plotdata_nopti_path_ns);     \
free(plot_command);               \
free(plot_output_path);

void plot(char*);
void plot_fm_syscalls(uint64_t*, uint64_t*, char*, char*);
void plot_fork_syscall(uint64_t*, uint64_t*, char*, char*);
void plot_pc_syscalls(uint64_t*, uint64_t*, char*, char*);
void plot_loss_percentage(uint64_t*, uint64_t*, char*, char*);
void plot_tlb(char*, char*, char*);
int create_tlb_plotfile(char*, char*, char*, char**);




#endif
