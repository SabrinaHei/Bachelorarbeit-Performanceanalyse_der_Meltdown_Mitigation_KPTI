#define _GNU_SOURCE

#include <stdio.h>
#include <stdint.h>
#include <sched.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#include "analyse.h"
#include "../system_specs/system_specs.h"


uint64_t overhead_cycles;
uint64_t overhead_seconds;


//Misst die benötigten Zykel für File Management Systemcalls
void test_syscalls_fm_cycles(char* data_path) {
    FILE* fptr_analyse;

    uint64_t measured_time_start;
    uint64_t measured_time;

    uint64_t time_open[REP] = {0};
    uint64_t time_read[REP] = {0};
    uint64_t time_close[REP] = {0};

    uint64_t avg_time_open = 0;
    uint64_t avg_time_read = 0;
    uint64_t avg_time_close = 0;

    //Diese Datei wird für die File Management Systemcalls verwendet
    char* test_filename = "./code/analyse/testfile.txt";
    int test_fd;

    char read_buf[BUFFERSIZE];

    //Um nötige Daten im Cache und TLB zu haben, vorher einmal ausführen, für auch erste korrekte Messung
    if ((test_fd = open(test_filename, O_RDONLY)) == 0) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", test_filename);
    }
    read(test_fd, read_buf, BUFFERSIZE);
    close(test_fd);

    //Hier werden die benötigten Zykel gemessen
    for (int i = 0; i < REP; i++) {
        //Falls Adressen bzw. Cache-Inhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &open);
        prefetch((void *) &rdtsc);

        //Benötigte Anzahl von Zyklen für Systemcall open messen
        CYCLE_TIME_MEASUREMENT_START
        test_fd = open(test_filename, O_RDONLY);
        CYCLE_TIME_MEASUREMENT_END
        time_open[i] = measured_time;

        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &read);
        prefetch((void *) &rdtsc);

        //Benötigte Anzahl von Zyklen für Systemcall read messen
        CYCLE_TIME_MEASUREMENT_START
        read(test_fd, read_buf, BUFFERSIZE);
        CYCLE_TIME_MEASUREMENT_END
        time_read[i] = measured_time;

        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &close);
        prefetch((void *) &rdtsc);

        //Benötigte Anzahl von Zyklen für Systemcall close messen
        CYCLE_TIME_MEASUREMENT_START
        close(test_fd);
        CYCLE_TIME_MEASUREMENT_END
        time_close[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }

    //Datei für Schreiben von Ergebnissen dieses Testlaufs öffnen
    if ((fptr_analyse = fopen(data_path, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", data_path);
        exit(1);
    }

    //Spaltentitel in Datei schreiben
    fprintf(fptr_analyse, "cycles-open cycles-read cycles-close\n");

    //Werte aus Messung in Datei schreiben und alle Werte für Durchschnittsberechnung einzeln addieren
    for (int i = 0; i < REP; i++) {
        fprintf(fptr_analyse, "%lu %lu %lu\n", time_open[i], time_read[i], time_close[i]);
        avg_time_open += time_open[i];
        avg_time_read += time_read[i];
        avg_time_close += time_close[i];
    }

    //Durchschnittszeiten berechnen
    avg_time_open /= REP;
    avg_time_read /= REP;
    avg_time_close /= REP;

    //Konsolenausgabe
    printf("\nDurchschnittlich benötigte Anzahl von Zyklen für folgende Systemcalls:\n");
    printf("Open: \t%lu Zykel\n", avg_time_open);
    printf("Read: \t%lu Zykel\n", avg_time_read);
    printf("Close: \t%lu Zykel\n", avg_time_close);

    fclose(fptr_analyse);
}


//Misst die benötigte Zeit in ns für File Management Systemcalls
void test_syscalls_fm_seconds(char* data_path) {
    FILE* fptr_analyse_old;
    FILE* fptr_analyse_new;

    char* tmp_filename = malloc(100 * sizeof(char));
    memset(tmp_filename, '\0', sizeof(&tmp_filename));
    strcat(tmp_filename, data_path);
    strcat(tmp_filename, "_TMP");

    uint64_t measured_time;

    uint64_t time_open[REP] = {0};
    uint64_t time_read[REP] = {0};
    uint64_t time_close[REP] = {0};

    uint64_t avg_time_open = 0;
    uint64_t avg_time_read = 0;
    uint64_t avg_time_close = 0;

    //Diese Datei wird für die File Management Systemcalls verwendet
    char *test_filename = "./code/analyse/testfile.txt";
    int test_fd;

    char read_buf[BUFFERSIZE];

    int val_c[3];       //Speichert die Werte aus vorheriger Messung zwischen
    char *category[3];  //Speichert die Spaltentitel aus vorheriger Messung
    for (int i = 0; i < 3; i++) {
        category[i] = malloc(20 * sizeof(char));
    }

    struct timespec timestamp_start, timestamp_end;

    //Um nötige Daten im Cache und TLB zu haben, vorher einmal ausführen, für auch erste korrekte Messung
    if ((test_fd = open(test_filename, O_RDONLY)) == 0) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", test_filename);
    }
    read(test_fd, read_buf, BUFFERSIZE);
    close(test_fd);

    //Hier werden die benötigten Zeiten gemessen
    for (int i = 0; i < REP; i++) {
        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &open);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall open messen
        SECONDS_TIME_MEASUREMENT_START
        test_fd = open(test_filename, O_RDONLY);
        SECONDS_TIME_MEASUREMENT_END
        time_open[i] = measured_time;

        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &read);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall read messen
        SECONDS_TIME_MEASUREMENT_START
        read(test_fd, read_buf, BUFFERSIZE);
        SECONDS_TIME_MEASUREMENT_END
        time_read[i] = measured_time;

        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &close);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall close messen
        SECONDS_TIME_MEASUREMENT_START
        close(test_fd);
        SECONDS_TIME_MEASUREMENT_END
        time_close[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }


    //Dateien für Schreiben/Zusammenführen von Ergebnissen dieses Testlaufs öffnen
    if ((fptr_analyse_old = fopen(data_path, "r+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", data_path);
        exit(1);
    }
    if ((fptr_analyse_new = fopen(tmp_filename, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s'\e[39;0m\n", tmp_filename);
        exit(1);
    }

    //Spaltentitel in Datei zusammenführen
    fscanf(fptr_analyse_old, "%s %s %s\n", category[0], category[1], category[2]);
    fprintf(fptr_analyse_new, "%s %s %s %s %s %s\n", category[0], category[1], category[2], "ns-open", "ns-read", "ns-close");

    //Werte aus vorherigen Messungen in Datei zusammenführen und alle Werte für Durchschnittsberechnung einzeln addieren
    for (int i = 0; i < REP; i++) {
        fscanf(fptr_analyse_old, "%d %d %d\n", &val_c[0], &val_c[1], &val_c[2]);
        fprintf(fptr_analyse_new, "%d %d %d %lu %lu %lu\n", val_c[0], val_c[1], val_c[2], time_open[i], time_read[i], time_close[i]);
        avg_time_open += time_open[i];
        avg_time_read += time_read[i];
        avg_time_close += time_close[i];
    }

    //Durchschnittszeiten berechnen
    avg_time_open /= REP;
    avg_time_read /= REP;
    avg_time_close /= REP;

    //Konsolenausgabe
    printf("\nDurchschnittlich benötigte Zeit für folgende Systemcalls:\n");
    printf("Open: \t%lu ns\n", avg_time_open);
    printf("Read: \t%lu ns\n", avg_time_read);
    printf("Close: \t%lu ns\n", avg_time_close);

    //Speicher freigeben, Dateien schließen, Temporäre Datei umbenennen
    for (int i = 0; i < 3; i++) {
        free(category[i]);
    }
    fclose(fptr_analyse_old);
    fclose(fptr_analyse_new);
    if (rename(tmp_filename, data_path) != 0)
        printf("Umbenennen von temporärer Datei '%s' zu Originaldatei '%s' fehlgeschlagen\n", tmp_filename, data_path);
    free(tmp_filename);
}


//Misst die benötigten Zykel für Process Control Systemcalls
void test_syscalls_pc_cycles(char* data_path) {
    FILE* fptr_analyse_old;
    FILE* fptr_analyse_new;
    FILE* fptr_fork_cycles;

    char* tmp_filename = malloc(100 * sizeof(char));
    memset(tmp_filename, '\0', sizeof(&tmp_filename));
    strcat(tmp_filename, data_path);
    strcat(tmp_filename, "_TMP");

    uint64_t measured_time_start;
    uint64_t measured_time;

    char* fork_call = malloc(30 * sizeof(char));
    memset(fork_call, 0, 30 * sizeof(char));
    char overhead[5];

    strcpy(fork_call, "./code/obj/fork c");
    snprintf(overhead, sizeof(overhead), " %lu", overhead_cycles);
    strcat(fork_call, overhead);

    //Zum zwischenspeichern der Messdaten
    uint64_t* time_fork = malloc(REP * sizeof(uint64_t));
    memset(time_fork, 0, REP * sizeof(uint64_t));
    uint64_t* time_getpid = malloc(REP * sizeof(uint64_t));
    memset(time_getpid, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_b = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_b, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_b = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_b, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_kb = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_kb, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_kb = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_kb, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_mb = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_mb, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_mb = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_mb, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_gb = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_gb, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_gb = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_gb, 0, REP * sizeof(uint64_t));

    uint64_t avg_time_fork = 0;
    uint64_t avg_time_getpid = 0;
    uint64_t avg_time_mmap_b = 0;
    uint64_t avg_time_munmap_b = 0;
    uint64_t avg_time_mmap_kb = 0;
    uint64_t avg_time_munmap_kb = 0;
    uint64_t avg_time_mmap_mb = 0;
    uint64_t avg_time_munmap_mb = 0;
    uint64_t avg_time_mmap_gb = 0;
    uint64_t avg_time_munmap_gb = 0;

    int val_c[6];       //Speichert die Werte aus vorheriger Messung zwischen
    char* category[6];  //Speichert die Spaltentitel aus vorheriger Messung
    for (int i = 0; i < 6; i++) {
        category[i] = malloc(20 * sizeof(char));
    }
    char* ptr_mmap;


//Hier werden die benötigten Zykel gemessen

    //Um nötige Daten in versch. Caches abgelegt zu haben, vorher einmal ausführen, für auch erste korrekte Messung
    getpid();


    //Benötigte Anzahl von Zykel für Systemcall getpid messen
    for (int i = 0; i < REP; i++) {
        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &getpid);
        prefetch((void *) &rdtsc);

        CYCLE_TIME_MEASUREMENT_START
        getpid();
        CYCLE_TIME_MEASUREMENT_END
        time_getpid[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }

    //Einzelnes Programm zum messen der Fork-Zeiten starten
    //verwendet minimale Menge an Speicher, der für Messungen benötigt wird
    //->Größe des zu kopierenden Prozessspeichers bleibt gleich und ändert sich nicht dynamisch (in Abhängigkeit der Anzahl von Wiederholungen REP)
    system(fork_call);
    //Messwerte in Datei geschrieben, die später ausgelesen wird

    //Für erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, BYTE, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, BYTE);

    for (int i = 0; i < REP; i++) {
        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &rdtsc);

        //Benötigte Anzahl von Zykel für Systemcall mmap messen - 1 Byte
        CYCLE_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, BYTE, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        CYCLE_TIME_MEASUREMENT_END
        time_mmap_b[i] = measured_time;
        //Benötigte Anzahl von Zykel für Systemcall munmap messen - 1 Byte
        CYCLE_TIME_MEASUREMENT_START
        munmap(ptr_mmap, BYTE);
        CYCLE_TIME_MEASUREMENT_END
        time_munmap_b[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }

    //Für erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, KB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, KB);

    for (int i = 0; i < REP; i++) {
        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &rdtsc);

        //Benötigte Anzahl von Zykel für Systemcall mmap messen - 1 KiB
        CYCLE_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, KB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        CYCLE_TIME_MEASUREMENT_END
        time_mmap_kb[i] = measured_time;
        //Benötigte Anzahl von Zykel für Systemcall munmap messen - 1 KiB
        CYCLE_TIME_MEASUREMENT_START
        munmap(ptr_mmap, KB);
        CYCLE_TIME_MEASUREMENT_END
        time_munmap_kb[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }


    //Für erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, MB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, MB);

    for (int i = 0; i < REP; i++) {
        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &rdtsc);

        //Benötigte Anzahl von Zykel für Systemcall mmap messen - 1 MiB
        CYCLE_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, MB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        CYCLE_TIME_MEASUREMENT_END
        time_mmap_mb[i] = measured_time;
        //Benötigte Anzahl von Zykel für Systemcall munmap messen - 1 MiB
        CYCLE_TIME_MEASUREMENT_START
        munmap(ptr_mmap, MB);
        CYCLE_TIME_MEASUREMENT_END
        time_munmap_mb[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }


    //Für erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, GB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, GB);

    for (int i = 0; i < REP; i++) {
        //Falls Adressen bzw. Cacheinhalte von benötigten Funktionen verdrängt wurden, alle Daten wieder holen
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &rdtsc);

        //Benötigte Anzahl von Zykel für Systemcall mmap messen - 1 GiB
        CYCLE_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, GB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        CYCLE_TIME_MEASUREMENT_END
        time_mmap_gb[i] = measured_time;
        //Benötigte Anzahl von Zykel für Systemcall munmap messen - 1 GiB
        CYCLE_TIME_MEASUREMENT_START
        munmap(ptr_mmap, GB);
        CYCLE_TIME_MEASUREMENT_END
        time_munmap_gb[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }

    //Dateien für Schreiben von Ergebnissen dieses Testlaufs öffnen
    if ((fptr_analyse_old = fopen(data_path, "r+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", data_path);
        exit(1);
    }
    if ((fptr_analyse_new = fopen(tmp_filename, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", tmp_filename);
        exit(1);
    }
    if ((fptr_fork_cycles = fopen(F_FORK_CYCLE, "r+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", F_FORK_CYCLE);
        exit(1);
    }

    //Fork Zeiten auslesen
    for (int i = 0; i < REP; i++) {
        fscanf(fptr_fork_cycles, "%lu\n", &time_fork[i]);
    }


    //Spaltentitel in Datei zusammenführen
    fscanf(fptr_analyse_old, "%s %s %s %s %s %s\n", category[0], category[1], category[2], category[3], category[4], category[5]);
    fprintf(fptr_analyse_new, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n", category[0], category[1], category[2], category[3], category[4], category[5],
            "cycles-fork", "cycles-getpid", "cycles-mmap_1B", "cycles-munmap_1B", "cycles-mmap_1KiB", "cycles-munmap_1KiB", "cycles-mmap_1MiB", "cycles-munmap_1MiB",
            "cycles-mmap_1GiB", "cycles-munmap_1GiB");

    //Werte aus vorherigen Messungen in Datei zusammenführen und alle Werte für Durchschnittsberechnung einzeln addieren
    for (int i = 0; i < REP; i++) {
        fscanf(fptr_analyse_old, "%d %d %d %d %d %d\n", &val_c[0], &val_c[1], &val_c[2], &val_c[3], &val_c[4], &val_c[5]);
        fprintf(fptr_analyse_new, "%d %d %d %d %d %d %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n", val_c[0], val_c[1], val_c[2], val_c[3], val_c[4], val_c[5],
                time_fork[i], time_getpid[i], time_mmap_b[i], time_munmap_b[i], time_mmap_kb[i], time_munmap_kb[i], time_mmap_mb[i], time_munmap_mb[i],
                time_mmap_gb[i], time_munmap_gb[i]);
        avg_time_fork += time_fork[i];
        avg_time_getpid += time_getpid[i];
        avg_time_mmap_b += time_mmap_b[i];
        avg_time_munmap_b += time_munmap_b[i];
        avg_time_mmap_kb += time_mmap_kb[i];
        avg_time_munmap_kb += time_munmap_kb[i];
        avg_time_mmap_mb += time_mmap_mb[i];
        avg_time_munmap_mb += time_munmap_mb[i];
        avg_time_mmap_gb += time_mmap_gb[i];
        avg_time_munmap_gb += time_munmap_gb[i];
    }

    //Durchschnittszykel berechnen
    avg_time_fork /= REP;
    avg_time_getpid /= REP;
    avg_time_mmap_b /= REP;
    avg_time_munmap_b /= REP;
    avg_time_mmap_kb /= REP;
    avg_time_munmap_kb /= REP;
    avg_time_mmap_mb /= REP;
    avg_time_munmap_mb /= REP;
    avg_time_mmap_gb /= REP;
    avg_time_munmap_gb /= REP;

    //Konsolenausgabe
    printf("\nDurchschnittlich benötigte Anzahl von Zyklen für folgende Systemcalls:\n");
    printf("Fork: \t\t%6lu Zykel\n", avg_time_fork);
    printf("Getpid:\t\t%6lu Zykel\n", avg_time_getpid);
    printf("Mmap (1 Byte):\t%6lu Zykel\n", avg_time_mmap_b);
    printf("Munmap (1 Byte):%6lu Zykel\n", avg_time_munmap_b);
    printf("Mmap (1 KiB):\t%6lu Zykel\n", avg_time_mmap_kb);
    printf("Munmap (1 KiB):\t%6lu Zykel\n", avg_time_munmap_kb);
    printf("Mmap (1 MiB):\t%6lu Zykel\n", avg_time_mmap_mb);
    printf("Munmap (1 MiB):\t%6lu Zykel\n", avg_time_munmap_mb);
    printf("Mmap (1 GiB):\t%6lu Zykel\n", avg_time_mmap_gb);
    printf("Munmap (1 GiB):\t%6lu Zykel\n\n", avg_time_munmap_gb);


    //Abschluss
    for (int i = 0; i < 6; i++) {
        free(category[i]);
    }

    free(time_fork);
    free(time_getpid);
    free(time_mmap_b);
    free(time_munmap_b);
    free(time_mmap_kb);
    free(time_munmap_kb);
    free(time_mmap_mb);
    free(time_munmap_mb);
    free(time_mmap_gb);
    free(time_munmap_gb);
    free(fork_call);

    fclose(fptr_analyse_old);
    fclose(fptr_analyse_new);
    fclose(fptr_fork_cycles);

    if (rename(tmp_filename, data_path) != 0)
        printf("Umbenennen von temporärer Datei %s zu Originaldatei %s fehlgeschlagen\n", tmp_filename, data_path);
    free(tmp_filename);
    remove(F_FORK_CYCLE);
}


//Misst die benötigte Zeit in ns für Process Control Systemcalls
void test_syscalls_pc_seconds(char* data_path) {
    FILE* fptr_analyse_old;
    FILE* fptr_analyse_new;
    FILE* fptr_fork_ns;
    char* tmp_filename = malloc(100 * sizeof(char));
    memset(tmp_filename, '\0', sizeof(&tmp_filename));
    strcat(tmp_filename, data_path);
    strcat(tmp_filename, "_TMP");

    uint64_t measured_time;

    char* fork_call = malloc(30 * sizeof(char));
    memset(fork_call, 0, 30 * sizeof(char));
    char overhead[5];

    strcpy(fork_call, "./code/obj/fork ns");
    snprintf(overhead, sizeof(overhead), " %lu", overhead_seconds);
    strcat(fork_call, overhead);

    //Zum zwischenspeichern der Messdaten
    uint64_t* time_fork = malloc(REP * sizeof(uint64_t));
    memset(time_fork, 0, REP * sizeof(uint64_t));
    uint64_t* time_getpid = malloc(REP * sizeof(uint64_t));
    memset(time_getpid, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_b = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_b, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_b = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_b, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_kb = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_kb, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_kb = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_kb, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_mb = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_mb, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_mb = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_mb, 0, REP * sizeof(uint64_t));
    uint64_t* time_mmap_gb = malloc(REP * sizeof(uint64_t));
    memset(time_mmap_gb, 0, REP * sizeof(uint64_t));
    uint64_t* time_munmap_gb = malloc(REP * sizeof(uint64_t));
    memset(time_munmap_gb, 0, REP * sizeof(uint64_t));

    uint64_t avg_time_fork = 0;
    uint64_t avg_time_getpid = 0;
    uint64_t avg_time_mmap_b = 0;
    uint64_t avg_time_munmap_b = 0;
    uint64_t avg_time_mmap_kb = 0;
    uint64_t avg_time_munmap_kb = 0;
    uint64_t avg_time_mmap_mb = 0;
    uint64_t avg_time_munmap_mb = 0;
    uint64_t avg_time_mmap_gb = 0;
    uint64_t avg_time_munmap_gb = 0;

    int val_c[16];
    char* category[16];
    for (int i = 0; i < 16; i++) {
        category[i] = malloc(20 * sizeof(char));
    }
    char* ptr_mmap;
    struct timespec timestamp_start, timestamp_end;

//Hier werden die benötigten Zeiten gemessen

    //Um nötige Daten in versch. Caches abgelegt zu haben, vorher einmal ausführen, für auch erste korrekte Messung
    getpid();

    prefetch((void *) &getpid);
    prefetch((void *) &clock_gettime);
    for (int i = 0; i < REP; i++) {
        prefetch((void *) &getpid);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall getpid messen
        SECONDS_TIME_MEASUREMENT_START
        getpid();
        SECONDS_TIME_MEASUREMENT_END
        time_getpid[i] = measured_time;

        sched_yield();  //Für möglichst unterbrechungsfreie Messungen
    }

    //Einzelnes Programm zum messen der Fork-Zeiten starten (Erklärung siehe oben in entsprechender Zykel Funktion)
    system(fork_call);

    //Für je erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, BYTE, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, BYTE);

    for (int i = 0; i < REP; i++) {
        //Daten wieder in Caches holen, falls verdrängt
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall mmap messen - 1 Byte
        SECONDS_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, BYTE, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        SECONDS_TIME_MEASUREMENT_END
        time_mmap_b[i] = measured_time;
        //Benötigte Zeit für Systemcall munmap messen - 1 Byte
        SECONDS_TIME_MEASUREMENT_START
        munmap(ptr_mmap, BYTE);
        SECONDS_TIME_MEASUREMENT_END
        time_munmap_b[i] = measured_time;

        sched_yield(); //Für möglichst unterbrechungsfreie Messungen
    }


    //Für je erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, KB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, KB);

    for (int i = 0; i < REP; i++) {
        //Daten wieder in Caches holen, falls verdrängt
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall mmap messen - 1 KiB
        SECONDS_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, KB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        SECONDS_TIME_MEASUREMENT_END
        time_mmap_kb[i] = measured_time;
        //Benötigte Zeit für Systemcall munmap messen - 1 KiB
        SECONDS_TIME_MEASUREMENT_START
        munmap(ptr_mmap, KB);
        SECONDS_TIME_MEASUREMENT_END
        time_munmap_kb[i] = measured_time;
    }

    //Für je erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, MB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, MB);

    for (int i = 0; i < REP; i++) {
        //Daten wieder in Caches holen, falls verdrängt
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall mmap messen - 1 MiB
        SECONDS_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, MB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        SECONDS_TIME_MEASUREMENT_END
        time_mmap_mb[i] = measured_time;
        //Benötigte Zeit für Systemcall munmap messen - 1 MiB
        SECONDS_TIME_MEASUREMENT_START
        munmap(ptr_mmap, MB);
        SECONDS_TIME_MEASUREMENT_END
        time_munmap_mb[i] = measured_time;

        sched_yield(); //Für möglichst unterbrechungsfreie Messungen
    }

    //Für je erste Korrekte Messung einmal mmap und munmap ausführen
    ptr_mmap = mmap(NULL, GB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
    munmap(ptr_mmap, GB);

    for (int i = 0; i < REP; i++) {
        //Daten wieder in Caches holen, falls verdrängt
        prefetch((void *) &mmap);
        prefetch((void *) &munmap);
        prefetch((void *) &clock_gettime);

        //Benötigte Zeit für Systemcall mmap messen - 1 GiB
        SECONDS_TIME_MEASUREMENT_START
        ptr_mmap = mmap(NULL, GB, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
        SECONDS_TIME_MEASUREMENT_END
        time_mmap_gb[i] = measured_time;
        //Benötigte Zeit für Systemcall munmap messen - 1 GiB
        SECONDS_TIME_MEASUREMENT_START
        munmap(ptr_mmap, GB);
        SECONDS_TIME_MEASUREMENT_END
        time_munmap_gb[i] = measured_time;

        //Für möglichst unterbrechungsfreie Ausführung in nächstem Durchlauf Bereitschaft für Scheduling anderer Prozesse signalisieren
        sched_yield();
    }



    //Dateien für Schreiben von Ergebnissen dieses Testlaufs öffnen
    if ((fptr_analyse_old = fopen(data_path, "r+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", data_path);
        exit(1);
    }
    if ((fptr_analyse_new = fopen(tmp_filename, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", tmp_filename);
        exit(1);
    }
    if ((fptr_fork_ns = fopen(F_FORK_NS, "r+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", F_FORK_NS);
        exit(1);
    }

    //Fork Zeiten auslesen
    for (int i = 0; i < REP; i++) {
        fscanf(fptr_fork_ns, "%lu\n", &time_fork[i]);
    }


    //Spaltentitel in Datei zusammenführen
    fscanf(fptr_analyse_old, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n", category[0], category[1], category[2],
           category[3], category[4], category[5], category[6], category[7], category[8], category[9], category[10],
           category[11], category[12], category[13], category[14], category[15]);
    fprintf(fptr_analyse_new, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
            category[0], category[1], category[2], category[3], category[4], category[5], category[6], category[7], category[8],
            category[9], category[10], category[11], category[12], category[13], category[14], category[15],
            "ns-fork", "ns-getpid", "ns-mmap_1B", "ns-munmap_1B", "ns-mmap_1KiB", "ns-munmap_1KiB",
            "ns-mmap_1MiB", "ns-munmap_1MiB", "ns-mmap_1GiB", "ns-munmap_1GiB");

    //Werte aus vorherigen Messungen in Datei zusammenführen und alle Werte für Durchschnittsberechnung einzeln addieren
    for (int i = 0; i < REP; i++) {
        fscanf(fptr_analyse_old, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n", &val_c[0], &val_c[1], &val_c[2],
               &val_c[3], &val_c[4], &val_c[5], &val_c[6], &val_c[7], &val_c[8], &val_c[9], &val_c[10], &val_c[11],
               &val_c[12], &val_c[13], &val_c[14], &val_c[15]);
        fprintf(fptr_analyse_new,"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n",
                val_c[0], val_c[1], val_c[2], val_c[3], val_c[4], val_c[5], val_c[6], val_c[7], val_c[8], val_c[9], val_c[10],
                val_c[11], val_c[12], val_c[13], val_c[14], val_c[15], time_fork[i], time_getpid[i], time_mmap_b[i], time_munmap_b[i],
                time_mmap_kb[i], time_munmap_kb[i], time_mmap_mb[i], time_munmap_mb[i], time_mmap_gb[i], time_munmap_gb[i]);
        avg_time_fork += time_fork[i];
        avg_time_getpid += time_getpid[i];
        avg_time_mmap_b += time_mmap_b[i];
        avg_time_munmap_b += time_munmap_b[i];
        avg_time_mmap_kb += time_mmap_kb[i];
        avg_time_munmap_kb += time_munmap_kb[i];
        avg_time_mmap_mb += time_mmap_mb[i];
        avg_time_munmap_mb += time_munmap_mb[i];
        avg_time_mmap_gb += time_mmap_gb[i];
        avg_time_munmap_gb += time_munmap_gb[i];
    }

    //Durchschnittszeiten berechnen
    avg_time_fork /= REP;
    avg_time_getpid /= REP;
    avg_time_mmap_b /= REP;
    avg_time_munmap_b /= REP;
    avg_time_mmap_kb /= REP;
    avg_time_munmap_kb /= REP;
    avg_time_mmap_mb /= REP;
    avg_time_munmap_mb /= REP;
    avg_time_mmap_gb /= REP;
    avg_time_munmap_gb /= REP;

    //Konsolenausgabe
    printf("Durchschnittlich benötigte Zeit für folgende Systemcalls:\n");
    printf("Fork:\t\t%6lu ns\n", avg_time_fork);
    printf("Getpid:\t\t%6lu ns\n", avg_time_getpid);
    printf("Mmap (1 Byte):\t%6lu ns\n", avg_time_mmap_b);
    printf("Munmap (1 Byte):%6lu ns\n", avg_time_munmap_b);
    printf("Mmap (1 KiB):\t%6lu ns\n", avg_time_mmap_kb);
    printf("Munmap (1 KiB):\t%6lu ns\n", avg_time_munmap_kb);
    printf("Mmap (1 MiB):\t%6lu ns\n", avg_time_mmap_mb);
    printf("Munmap (1 MiB):\t%6lu ns\n", avg_time_munmap_mb);
    printf("Mmap (1 GiB):\t%6lu ns\n", avg_time_mmap_gb);
    printf("Munmap (1 GiB):\t%6lu ns\n", avg_time_munmap_gb);


    //Abschließen
    for (int i = 0; i < 16; i++) {
        free(category[i]);
    }

    free(time_fork);
    free(time_getpid);
    free(time_mmap_b);
    free(time_munmap_b);
    free(time_mmap_kb);
    free(time_munmap_kb);
    free(time_mmap_mb);
    free(time_munmap_mb);
    free(time_mmap_gb);
    free(time_munmap_gb);
    free(fork_call);

    fclose(fptr_analyse_old);
    fclose(fptr_analyse_new);
    fclose(fptr_fork_ns);

    if (rename(tmp_filename, data_path) != 0)
        printf("Umbenennen von temporärer Datei %s zu Originaldatei %s fehlgeschlagen\n", tmp_filename, data_path);
    free(tmp_filename);
    remove(F_FORK_NS);
}


// Misst TLB Belegung nach Kontext Wechsel
void test_tlb_occupancy(char* data_path) {
	FILE* fptr;
	int test_size = TLB_TEST_SIZE;            // Anzahl Testadressen
	int evict_size = 5000;        // Anzahl Verdrängungsadressen
	int shm_fd = 0;               // Shared Memory File Deskriptor

	uint64_t measured_time_start;
	uint64_t measured_time;

	// Zur Speicherung von Messwerten in entsprechendes Histogramm Array
	uint64_t hit_histogram[HIST_SIZE];      //Zeiten TLB Hit
	memset(hit_histogram, '\0', HIST_SIZE * sizeof(uint64_t));
	uint64_t miss_histogram[HIST_SIZE];     //Zeiten TLB Miss
	memset(miss_histogram, 0, HIST_SIZE * sizeof(uint64_t));
	uint64_t measure_histogram[HIST_SIZE];  //Zeiten Messung nach Kontext Wechsel
	memset(measure_histogram, 0, HIST_SIZE * sizeof(uint64_t));

	// Variablendeklarationen im Zusammenhang mit Threshold
	uint64_t threshold = 0;
	uint64_t over_thresh = 0;
	uint64_t hit_most = 0;
	uint64_t hit_most_index = -1;
	uint64_t miss_most = 0;
	uint64_t miss_most_index = -1;
	uint64_t measure_most = 0;
	uint64_t measure_most_index = -1;


	uint8_t* addr_totest[test_size];			// Testadressen
	uint8_t* addr_toevict[evict_size];			// Verdrängungsadressen


//Shared Memory initialisieren - Für Mapping von allen zur Messung verwendeten virtuellen Adressen auf dieselbe physische Adresse

	// Filedeskriptor öffnen für Shared Memory Segment
	shm_fd = shm_open("shm", O_RDWR | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO );
	if (shm_fd < 0) {
		printf("Filedeskriptor für Shared Memory konnte nicht erstellt werden. Fehlercode %d", errno);
		exit(EXIT_FAILURE);
	}

	// Setze Größe auf Größe einer Page = 4096 Byte
	if (ftruncate(shm_fd, PAGE_SIZE * sizeof(uint8_t)) == -1) {
		printf("Größe für Shared Memory konnte nicht geändert werden. Fehlercode %d", errno);
		exit(EXIT_FAILURE);
	}

	// Shared Memory Segment in diesen Adressraum mappen - Verdrängungsadressen
	for (int i = 0; i < evict_size; i++) {
		addr_toevict[i] = (uint8_t *) mmap(NULL, PAGE_SIZE * sizeof(uint8_t), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
		if (addr_toevict[i] == MAP_FAILED) {
			printf("Fehler beim Mapping von Shared Memory. Fehlercode %d", errno);
			exit(EXIT_FAILURE);
		}
	}

	// Shared Memory Segment in diesen Adressraum mappen - Testadressen
	for (int i = 0; i < test_size; i++) {
		addr_totest[i] = (uint8_t *) mmap(NULL, PAGE_SIZE * sizeof(uint8_t), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
		if (addr_totest[i] == MAP_FAILED) {
			printf("Fehler beim Mapping von Shared Memory. Fehlercode %d", errno);
			exit(EXIT_FAILURE);
		}
	}

	printf("\nVerwendete virtuelle Adressen:\n");
	printf("-> Testadressen: %d Pages, %p - %p\n", test_size, addr_totest[test_size-1], addr_totest[0]);
	printf("-> Verdrängungsadressen: %d Pages, %p - %p\n", evict_size,addr_toevict[evict_size-1], addr_toevict[0]);
	printf("Verwendete Systemcalls für Kontext Wechsel: getpid, mmap, munmap\n");

// Beginn der Messungen

	printf("\n\e[39;1mBestimme Threshold zwischen TLB Miss und TLB Hit...\e[39;0m\n");
	printf("\n1. TLB Hit Zugriffszeit messen...\n");

/// Zeiten für TLB Hits messen
	for (int k = 0; k < REP; k++) {
		//Auf Test-Array zugreifen, sodass entsprechende Übersetzungen im TLB zwischengespeichert werden und Daten auch in CPU Cache vorhanden
		for (int i = 0; i < test_size; i++) {
			access_memory((void *) addr_totest[i]);
		}

		//Messung von Zykel Zeit für TLB Hit. Keine Latenzzeiten durch Cache Miss. Adressübersetzungen aus vorherigen Zugriffen in TLB vorhanden.
		for (int i = 0; i < test_size; i++) {
			CYCLE_TIME_MEASUREMENT_START
			access_memory((void *) addr_totest[i]);
			CYCLE_TIME_MEASUREMENT_END
			hit_histogram[MIN(HIST_SIZE - 1, measured_time)]++;
		}

		sched_yield(); 	// Für unterbrechungsfreiere Ausführung der Messung
	}

	// Maximum TLB Hit finden (häufigste Zeit)
	for (int i = 0; i < HIST_SIZE-1; i++) {
		if (hit_histogram[i] > hit_most) {
			hit_most = hit_histogram[i];
			hit_most_index = i;
		}
	}

	printf("Häufigste benötigte Anzahl von Zyklen bei TLB Hit: %lu Zykel\n", hit_most_index);
	printf("\n2. TLB Miss Zugriffszeit messen...\n");

/// Zeiten für TLB Misses messen
	for (int k = 0; k < REP; k++) {
		//Auf Test-Array zugreifen, sodass entsprechende Übersetzungen im TLB zwischengespeichert
		for (int i = 0; i < test_size; i++) {
			access_memory((void *) addr_totest[i]);
		}

		//Durch Zugriff auf andere Adressen TLB Einträge verdrängen,
		for (int i = 0; i < evict_size; i++) {
			access_memory((void *) addr_toevict[i]);
		}

		//Messung von Zykel Zeit für TLB Miss. Adressen aus erstem Aufruf in Schleife sind durch Evict-Array verdrängt worden
		for (int i = 0; i < test_size; i++) {
			CYCLE_TIME_MEASUREMENT_START
			access_memory((void *) addr_totest[i]);
			CYCLE_TIME_MEASUREMENT_END
			miss_histogram[MIN(HIST_SIZE - 1, measured_time)]++;
		}

		sched_yield(); // Für unterbrechungsfreiere Ausführung der Messungen
	}

	//Maximum TLB Miss finden (häufigste Zeit)
	for (int i = 0; i < HIST_SIZE-1; i++) {
		if (miss_histogram[i] > miss_most) {
			miss_most = miss_histogram[i];
			miss_most_index = i;
		}
	}

	printf("Häufigste benötigte Anzahl von Zyklen bei TLB Miss: %lu Zykel\n", miss_most_index);

	//Threshold berechnen und ausgeben
	threshold = (miss_most_index + hit_most_index) / 2;
	printf("\n\e[39;1mThreshold bestimmt: %lu Zykel\e[39;0m\n", threshold);

	printf("\n3. Messe Zugriffszeit auf zuvor im TLB gespeicherte Testadressen nach Kontext Wechsel...\n");

/// Eigentliche Messung der TLB Belegung
	for (int k = 0; k < REP; k++) {
		//Auf Test-Array zugreifen, sodass entsprechende Übersetzungen im TLB zwischengespeichert
		for (int i = 0; i < test_size; i++) {
			access_memory((void *) addr_totest[i]);
		}

		// Kontext Wechsel durch Aufruf von Systemcalls hervorrufen
		getpid();
		int* ptr_mmap = mmap(NULL, BYTE, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
		munmap(ptr_mmap, BYTE);

		//Erneuter Zugriff auf Testadressen
		for (int i = 0; i < test_size; i++) {
			CYCLE_TIME_MEASUREMENT_START
			access_memory((void *) addr_totest[i]);
			CYCLE_TIME_MEASUREMENT_END
			measure_histogram[MIN(HIST_SIZE - 1, measured_time)]++;
		}

		sched_yield(); // Für unterbrechungsfreiere Ausführung der Messungen
	}


	// Maximum Messung finden (häufigste Zeit)
	for (int i = 0; i < HIST_SIZE-1; i++) {
		if (measure_histogram[i] > measure_most) {
			measure_most = measure_histogram[i];
			measure_most_index = i;
		}
	}

	printf("Häufigste benötigte Anzahl von Zyklen bei Messung: %lu Zykel\n", measure_most_index);

	//Alle Zugriffe, die mehr Zeit als Threshold benötigen, werden als TLB Miss klassifiziert
	for (int i = 0; i < HIST_SIZE-1; i++) {
		if (i > threshold) over_thresh += measure_histogram[i];
	}

	printf("\nVon insgesamt %d Messungen der Zugriffszeit auf die Testadressen nach einem Kontext Wechsel wurden %lu (%.2f %%) als TLB Miss klassifiziert.\n",REP * test_size, over_thresh, (double)(over_thresh * 100) / (double)(REP * test_size));


	//Dateien für Schreiben von Ergebnissen dieses Testlaufs öffnen
	if ((fptr = fopen(data_path, "wb")) == NULL) {
		printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", data_path);
		exit(1);
	}

	//Spaltentitel schreiben
	fprintf(fptr, "Zykel TLB-Hit TLB-Miss TLB-CSwitch\n");

	//Ergebnisse in Datei schreiben
	for (int i = 0; i < HIST_SIZE; i++) {
		fprintf(fptr, "%d %lu %lu %lu\n", i, hit_histogram[i], miss_histogram[i], measure_histogram[i]);
	}

	fclose(fptr);

	close_shmem(addr_totest,test_size);
	close_shmem(addr_toevict,evict_size);
	close(shm_fd);
}


char* organize_tlb_files(char* data_path_tlb, int kpti_on) {
    char* f_tlb;
    char* data_path_tlb_file_rename = malloc(100 * sizeof(char));
    memset(data_path_tlb_file_rename, '\0', 100 * sizeof(char));
    char* data_path_tlb_file = malloc(100 * sizeof(char));
    memset(data_path_tlb_file, '\0', 100 * sizeof(char));

    if (kpti_on == 1) f_tlb = F_TLB_KPTI1;
    else f_tlb = F_TLB_NOPTI1;

    strcpy(data_path_tlb_file, data_path_tlb);
    strcat(data_path_tlb_file, f_tlb);

    if (access(data_path_tlb_file, F_OK) == 0) {
        //Datei 1 existiert bereits

        //Prüfe Datei 2
        strcpy(data_path_tlb_file, data_path_tlb);
        if (kpti_on == 1)f_tlb = F_TLB_KPTI2;
        else f_tlb = F_TLB_NOPTI2;
        strcat(data_path_tlb_file, f_tlb);
        if (access(data_path_tlb_file, F_OK) == 0) {
            //Datei 2 existiert bereits

            //Prüfe datei 3
            strcpy(data_path_tlb_file, data_path_tlb);
            if (kpti_on == 1)f_tlb = F_TLB_KPTI3;
            else f_tlb = F_TLB_NOPTI3;
            strcat(data_path_tlb_file, f_tlb);
            if (access(data_path_tlb_file, F_OK) == 0) {
                //Datei 3 existiert bereits

                //Prüfe datei 4
                strcpy(data_path_tlb_file, data_path_tlb);
                if (kpti_on == 1)f_tlb = F_TLB_KPTI4;
                else f_tlb = F_TLB_NOPTI4;
                strcat(data_path_tlb_file, f_tlb);
                if (access(data_path_tlb_file, F_OK) == 0) {
                    //Datei 4 existiert bereits

                    //Prüfe datei 5
                    strcpy(data_path_tlb_file, data_path_tlb);
                    if (kpti_on == 1)f_tlb = F_TLB_KPTI5;
                    else f_tlb = F_TLB_NOPTI5;
                    strcat(data_path_tlb_file, f_tlb);
                    if (access(data_path_tlb_file, F_OK) == 0) {
                        //Datei existiert bereits

                        //Um neue Messung aufzunehmen, älteste Messung löschen
                        //Alle Dateien "eins nach vorne rutschen" - FIFO
                        if (kpti_on == 1) {
                            //2->1
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_KPTI1);
                            strcat(data_path_tlb_file_rename, F_TLB_KPTI2);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //3->2
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_KPTI2);
                            strcat(data_path_tlb_file_rename, F_TLB_KPTI3);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //4->3
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_KPTI3);
                            strcat(data_path_tlb_file_rename, F_TLB_KPTI4);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //5->4
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_KPTI4);
                            strcat(data_path_tlb_file_rename, F_TLB_KPTI5);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //5 frei für neue Messung
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_KPTI5);
                        } else {
                            //2->1
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_NOPTI1);
                            strcat(data_path_tlb_file_rename, F_TLB_NOPTI2);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //3->2
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_NOPTI2);
                            strcat(data_path_tlb_file_rename, F_TLB_NOPTI3);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //4->3
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_NOPTI3);
                            strcat(data_path_tlb_file_rename, F_TLB_NOPTI4);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //5->4
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcpy(data_path_tlb_file_rename, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_NOPTI4);
                            strcat(data_path_tlb_file_rename, F_TLB_NOPTI5);
                            rename(data_path_tlb_file_rename, data_path_tlb_file);

                            //5 frei für neue Messung
                            strcpy(data_path_tlb_file, data_path_tlb);
                            strcat(data_path_tlb_file, F_TLB_NOPTI5);

                            free(data_path_tlb_file_rename);
                        }
                    }
                }
            }
        }
    }
    //Falls noch keine 5 Messungen vorliegen schlägt entsprechendes access() fehl
    //Dateipfad wird für neue Messung verwendet
    return data_path_tlb_file;
}


//Versionierung und System Spezifikationen
void write_specs_to_file(char* dir) {
    FILE* fd;
    char* path = malloc(100 * sizeof(char));
    memset(path, '\0', 100 * sizeof(char));
    char* specs;

    strcpy(path, dir);
    strcat(path, "system_specs.txt");

    //Versionierungsdatei öffnen und ggf. erzeugen oder überschreiben
    if ((fd = fopen(path, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s': %d\e[39;0m\n", path, errno);
        return;
    }

    //Infos in Datei schreiben
    fprintf(fd, "Versionierung und System Spezifikationen:\n");
    specs = get_specs();
    fprintf(fd, "%s\n", specs);

    //Schließen und Speicher freigeben
    fclose(fd);
    free(specs);
    free(path);
    return;
}

int main() {
///Initialisierungen & Deklarationen
    int kpti_on;
    char* f_analyse;
    uint64_t* avg_c;
    char** category;
    pid_t my_pid;

    uint64_t measured_time_start;
    uint64_t measured_time;
    struct timespec timestamp_start, timestamp_end;

    char* dir = malloc(100 * sizeof(char));
    memset(dir, '\0', 100 * sizeof(char));
    char* data_path_sysc = malloc(100 * sizeof(char));
    memset(data_path_sysc, '\0', 100 * sizeof(char));
    char* data_path_tlb = malloc(100 * sizeof(char));
    memset(data_path_tlb, '\0', 100 * sizeof(char));
    char* five_measurements_path = malloc(100 * sizeof(char));
    memset(five_measurements_path, '\0', 100 * sizeof(char));
    char* data_path_tlb_file;


///Compile-Parameter auslesen und Daten weiter verarbeiten

    //PCID Info ausgeben
#ifndef PCID
    printf("PCID: Es konnte nicht festgestellt werden, ob PCID verfügbar ist.\n");
#else
    if(atoi(PCID)==1)
        printf("PCID: Verfügbar\n");
    else
        printf("PCID: Nicht Verfügbar\n");
#endif

    //CPU Modell ausgeben
#ifndef CPU_FULLNAME
    printf("CPU Modell: nicht erkannt\n");
#else
    printf("Es wird folgende CPU verwendet: %s\n", CPU_FULLNAME);
#endif


    strcat(dir, "./results/");
    //Basis-Verzeichnis zur Ablage der Ergebnisse erstellen, falls noch nicht vorhanden
    struct stat base_dir = {0};
    if (stat(dir, &base_dir) == -1) {
        mkdir(dir, 0777);
    }

    //Kurzer CPU Name für Dateiablage in Ordner
#ifndef CPU_SHORTNAME
    strcat(dir, "current/");
#else
    strcat(dir,CPU_SHORTNAME);
    strcat(dir,"/");
#endif

    //Neues Verzeichnis zur Ablage der Ergebnisse in CPU-Ordner erstellen, falls noch nicht vorhanden
    if (stat(dir, &base_dir) == -1) {
        mkdir(dir, 0777);
    }

    //Pfade zur Dateiablage von Syscall Messungen erzeugen
    strcat(data_path_sysc, dir);
    strcat(data_path_sysc, "measurements-syscalls/");
    //Neues Verzeichnis zur Ablage der Ergebnisse erstellen, falls noch nicht vorhanden
    struct stat sysc_dir = {0};
    if (stat(data_path_sysc, &sysc_dir) == -1) {
        mkdir(data_path_sysc, 0777);
    }
    strcat(five_measurements_path, data_path_sysc);

    //Pfade zur Dateiablage von TLB Messungen erzeugen
    strcat(data_path_tlb, dir);
    strcat(data_path_tlb, "measurements-tlb/");
    //Neues Verzeichnis zur Ablage der Ergebnisse erstellen, falls noch nicht vorhanden
    struct stat tlb_dir = {0};
    if (stat(data_path_tlb, &tlb_dir) == -1) {
        mkdir(data_path_tlb, 0777);
    }

    //Infos über Verwendung von KPTI ausgeben
#ifndef KPTI
    printf("Es konnte nicht festgestellt werden, ob KPTI eingeschaltet ist oder nicht\n");
    exit(1);
#else
    kpti_on = atoi(KPTI);
#endif

    //Abhängig von KPTI Status Dateipfade erweitern
    if (kpti_on == 1) {
        f_analyse = F_ANALYSE_KPTI;
        printf("KPTI: Eingeschaltet\n");
        strcat(five_measurements_path, F_AVG_KPTI);
    } else {
        f_analyse = F_ANALYSE_NOPTI;
        printf("KPTI: Ausgeschaltet\n");
        strcat(five_measurements_path, F_AVG_NOPTI);
    }
    strcat(data_path_sysc, f_analyse);

    //TLB Dateien Verwalten
    data_path_tlb_file = organize_tlb_files(data_path_tlb, kpti_on);

    //Infos über dieses Gerät in Datei schreiben
    write_specs_to_file(dir);

    //Prozess an festen Kern binden
    my_pid = getpid();
    cpu_set_t my_set;                      //Für cpu Bitmaske
    CPU_ZERO(&my_set);              //Bitmaske auf 0 setzen
    CPU_SET(1, &my_set);        //Entsprechenden Kern maskieren: Kern 1
    sched_setaffinity(my_pid, sizeof(cpu_set_t), &my_set);   //CPU_affinity für diesen Prozess auf CPU Kern 1 setzen

    //Overhead der zur Messung verwendeten Befehle berechnen
    for (int i = 0; i < REP; i++) {
        CYCLE_TIME_MEASUREMENT_START
        measured_time = rdtsc() - measured_time_start;
        overhead_cycles += measured_time;
        sched_yield(); //Für möglichst unterbrechungsfreie Messungen
    }
    overhead_cycles /= REP;

    for (int i = 0; i < REP; i++) {
        SECONDS_TIME_MEASUREMENT_START
        clock_gettime(CLOCK_MONOTONIC, &timestamp_end);
        if (timestamp_start.tv_sec < timestamp_end.tv_sec) {
            if (timestamp_end.tv_sec - timestamp_start.tv_sec > 1) {
                measured_time = ((timestamp_end.tv_sec - timestamp_start.tv_sec) - 1) * MAX_NSEC;
            }
            measured_time += MAX_NSEC - timestamp_start.tv_nsec;
            measured_time += timestamp_end.tv_nsec;
        } else {
            measured_time = timestamp_end.tv_nsec - timestamp_start.tv_nsec;
        }
        overhead_seconds += measured_time;
        sched_yield(); //Für möglichst unterbrechungsfreie Messungen
    }
    overhead_seconds /= REP;


///Vorbereitungen abgeschlossen. Start der Analyse

    printf("\n\e[32mPerformanceanalyse von File Management Systemcalls wird durchgeführt (%d Wiederholte Messungen)...\e[39m\n", REP);
    test_syscalls_fm_cycles(data_path_sysc);
    test_syscalls_fm_seconds(data_path_sysc);

    printf("\n\e[32mPerformanceanalyse von Process Control Systemcalls wird durchgeführt (%d Wiederholte Messungen)... (Dies kann einige Augenblicke dauern)\e[39m\n", REP);
    test_syscalls_pc_cycles(data_path_sysc);
    test_syscalls_pc_seconds(data_path_sysc);

    printf("\n\e[32mPerformanceanalyse von TLB Belegung wird durchgeführt... \e[39m\n");
    test_tlb_occupancy(data_path_tlb_file);

    printf("\n\e[32mAnalysevorgang abgeschlossen.\e[39m\nDer durchschnittliche Messungsoverhead von %lu Zyklen bzw. %lu ns wurde von jeder Messung abgezogen.\n\n", overhead_cycles, overhead_seconds);

///Durchschnittswerte der Messung zu letzten gespeicherten 5 Durchgängen hinzufügen
    avg_c = avg(data_path_sysc);
    category = get_categories(data_path_sysc);
    save_last_five_measurements(five_measurements_path, category, avg_c);

    printf("Die Ergebnisse dieser Messung befinden sich in den Dateien \n-> '%s'\n-> '%s'\n", data_path_sysc, data_path_tlb_file);

///Info: Ausgabe weitere Vorgehensweise
    if (kpti_on == 1) {
        printf("\nUm KPTI automatisiert auszuschalten und den PC neuzustarten, führen Sie nun 'make nopti' aus.\n");
    } else {
        printf("\nUm KPTI automatisiert wieder einzuschalten und den PC neuzustarten, führen Sie nun 'make kpti' aus.\n");
    }
    printf("Achtung: Falls Sie eigenständig Veränderungen an Bootparametern vorgenommen haben, werden diese dadurch mit den Standardeinstellungen überschrieben. Sichern Sie ggf. die Datei /etc/default/grub\n");
    printf("\e[33mBeachten Sie nach dem Neustart, vor einer erneuten Analyse, dieses Programm vollständig neu zu kompilieren ;)\n1. $ make clean\n2. $ make\n3. $ make analyse\e[39m\n");

    printf("\nFühren Sie 'make eval' aus, wenn je mindestens eine Messung mit und ohne KPTI durchgeführt wurde (empfohlen werden 5 Durchläufe), um die Ergebnisse zu evaluieren und zu plotten.\n");

    //Speicher freigeben
    free(dir);
    free(data_path_sysc);
    free(data_path_tlb);
    free(data_path_tlb_file);
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) free(category[i]);
    free(category);
    free(five_measurements_path);
    free(avg_c);

    return 0;
}
