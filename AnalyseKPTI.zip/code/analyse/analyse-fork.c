#define _GNU_SOURCE

#include <stdio.h>
#include <stdint.h>
#include <sched.h>
#include <unistd.h>
#include <stdlib.h>
#include <wait.h>
#include <time.h>
#include <string.h>
#include <sys/mman.h>
#include <errno.h>


#include "analyse.h"


int main(int argc, char** argv){
	FILE* fptr;
	uint64_t measured_time_start;
	uint64_t measured_time;
	struct timespec timestamp_start,timestamp_end;
    uint64_t overhead_cycles;
    uint64_t overhead_seconds;

	pid_t my_pid=getpid();

	//Prozess an festen Kern binden
	cpu_set_t my_set;                      //Für cpu Bitmaske
	CPU_ZERO(&my_set);              //Bitmaske auf 0 setzen
	CPU_SET(2, &my_set);        //Entsprechenden Kern maskieren: Kern 2
	sched_setaffinity(my_pid, sizeof(cpu_set_t), &my_set);   //CPU_affinity für diesen Prozess auf CPU Kern 2 setzen

	if(argc<2){
		printf("Messung von Fork-Ausführungszeiten konnte nicht durchgeführt werden. Es muss 'c' oder 'ns' als Kommandozeilenparamter angegeben werden, um in Zyklen oder Nanosekunden zu messen.\n");
        exit(1);
	}
    if(argc<3){
        printf("Overhead der Messung muss als zweiter Kommandozeilenparameter übergeben werden.\n");
        exit(1);
    }


	if(!strcmp(argv[1],"c")) {
	    overhead_cycles = strtoul(argv[2], NULL, 10);

		//Datei für Schreiben von Ergebnissen dieses Testlaufs öffnen
		if ((fptr = fopen(F_FORK_CYCLE, "wb")) == NULL) {
			printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", F_FORK_CYCLE);
			exit(1);
		}
		

		for (int i = 0; i < REP; i++) {
			printf("\r\033[2K[Messung Fork Zykel: %d]", i);

			//Daten in versch. Caches holen, für auch erste korrekte Messung
			prefetch((void *) &fork);
			prefetch((void *) &rdtsc);

			//Benötigte Anzahl von Zykel für Systemcall fork messen
			CYCLE_TIME_MEASUREMENT_START
			my_pid = fork();
			CYCLE_TIME_MEASUREMENT_END
			if (my_pid == 0) {
				exit(0);
			} else {
				while (wait(NULL) > 0);
			}

			fprintf(fptr, "%lu\n", measured_time);
			sched_yield();
		}

		fclose(fptr);
		printf("\r\033[2K");
	}else if(!strcmp(argv[1],"ns")) {
        overhead_seconds = strtoul(argv[2], NULL, 10);

		//Datei für Schreiben von Ergebnissen dieses Testlaufs öffnen
		if ((fptr = fopen(F_FORK_NS, "wb")) == NULL) {
			printf("\e[31;1mFehler beim Öffnen der Datei %s\e[39;0m\n", F_FORK_NS);
			exit(1);
		}



		for (int i = 0; i < REP; i++) {
			printf("\r\033[2K[Messung Fork Nanosekunden: %d]", i);

			//Daten in versch. Caches holen, für auch erste korrekte Messung
			prefetch((void *) &fork);
			prefetch((void *) &clock_gettime);

			//Benötigte Zeit für Systemcall fork messen
			SECONDS_TIME_MEASUREMENT_START
			my_pid = fork();
			SECONDS_TIME_MEASUREMENT_END
			if (my_pid == 0) {
				exit(0);
			} else {
				while (wait(NULL) > 0);
			}


			fprintf(fptr, "%lu\n", measured_time);
			sched_yield();
		}

		fclose(fptr);
		printf("\r\033[2K");
	}else{
		printf("Messung von Fork-Ausführungszeiten konnte nicht durchgeführt werden. Parameter nicht erkannt\n");
	}

	return 0;
}