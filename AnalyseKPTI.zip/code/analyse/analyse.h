#ifndef ANALYSE
#define ANALYSE


#define F_ANALYSE_KPTI "measurements_KPTI.csv"
#define F_ANALYSE_NOPTI "measurements_NOPTI.csv"
#define F_AVG_KPTI "last_five_avg_kpti.csv"
#define F_AVG_NOPTI "last_five_avg_nopti.csv"

#define F_FORK_CYCLE "./code/forktest_c.txt"
#define F_FORK_NS "./code/forktest_ns.txt"

#define F_TLB_NOPTI1 "tlb_measurement_nopti_1.csv"
#define F_TLB_NOPTI2 "tlb_measurement_nopti_2.csv"
#define F_TLB_NOPTI3 "tlb_measurement_nopti_3.csv"
#define F_TLB_NOPTI4 "tlb_measurement_nopti_4.csv"
#define F_TLB_NOPTI5 "tlb_measurement_nopti_5.csv"

#define F_TLB_KPTI1 "tlb_measurement_kpti_1.csv"
#define F_TLB_KPTI2 "tlb_measurement_kpti_2.csv"
#define F_TLB_KPTI3 "tlb_measurement_kpti_3.csv"
#define F_TLB_KPTI4 "tlb_measurement_kpti_4.csv"
#define F_TLB_KPTI5 "tlb_measurement_kpti_5.csv"



#define BYTE 1
#define KB 1024
#define MB (KB*1024)
#define GB (MB*1024)
#define REP 200000 //Wiederholungen der Messung
#define BUFFERSIZE 82
#define MAX_NSEC 1000000000
#define PAGE_SIZE 4096
#define TLB_TEST_SIZE 4                     //Anzahl zur Messung verwendeter virtueller Adressen
#define MIN(a, b) ((a) > (b)) ? (b) : (a)   //berechnet Minimum aus zwei Werten
#define HIST_SIZE 200						//Histogrammgröße

#define NUMBER_OF_CATEGORIES 26

#define READ_CATEGORIES_ALL(fptr) \
fscanf(fptr, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n", category[0], category[1], category[2], category[3], category[4], category[5], category[6], category[7], category[8], category[9], category[10], category[11], category[12], category[13], category[14], category[15], category[16], category[17], category[18], category[19], category[20], category[21], category[22], category[23], category[24], category[25]);


//liest CPU Zykel Zeitstempel
static inline uint64_t rdtsc() {
	uint64_t eax, edx;
	__asm__ volatile ("lfence");
    __asm__ volatile ("mfence");
    __asm__ volatile (  "rdtsc"                 //Read Time Stamp Counter bestimmt Anzahl der vergangenen CPU-Zykel und speichert in Register EDX:EAX
	: "=a" (eax), "=d" (edx));                  //speichert die unteren bits in Variable eax und die oberen in Variable edx
    __asm__ volatile ("lfence");
	uint64_t rdx = (edx<<32) | eax;             //verschiebt in edx gespeicherte Bits in oberen Bit-Bereich von rdx und hängt eax durch OR an
	return rdx;
}

//Zugriff auf angegebene Speicheradresse
static inline void access_memory(void* address){
	__asm__ volatile ("movq (%0), %%rax\n"      //Zugriff: legt Adresse (0.Parameter address) in Register rax
	:                                           //Keine Output-Operanden
	: "c" (address)                             //Input-Operand address in register rcx
	: "rax");                                   //rax zur Zwischenspeicherung
}

static inline void prefetch(void* address) {
	__asm__ volatile ("prefetch (%0)\n"::"c" (address):);
}


#define CYCLE_TIME_MEASUREMENT_START \
         __asm__ volatile ("cpuid"); 	\
         measured_time_start = rdtsc();


#define CYCLE_TIME_MEASUREMENT_END \
		measured_time = rdtsc() - measured_time_start; \
        if(measured_time - overhead_cycles > 0) measured_time -= overhead_cycles; \
        else measured_time = 1;

#define SECONDS_TIME_MEASUREMENT_START \
		measured_time=0;                     \
		__asm__ volatile ("cpuid"); \
        clock_gettime(CLOCK_MONOTONIC,&timestamp_start); \

#define SECONDS_TIME_MEASUREMENT_END \
		clock_gettime(CLOCK_MONOTONIC,&timestamp_end); \
        if(timestamp_start.tv_sec<timestamp_end.tv_sec){ \
		if(timestamp_end.tv_sec-timestamp_start.tv_sec>1) { \
		measured_time = ((timestamp_end.tv_sec - timestamp_start.tv_sec) - 1) * MAX_NSEC; \
		} \
		measured_time += MAX_NSEC-timestamp_start.tv_nsec; \
		measured_time += timestamp_end.tv_nsec; \
		}else{ \
		measured_time =timestamp_end.tv_nsec-timestamp_start.tv_nsec; \
		} \
		if(measured_time - overhead_seconds > 0) measured_time -= overhead_seconds; \
        else measured_time = 1;


void close_shmem(uint8_t** addr, int size) {
	// Unmapping von Shared Memory
	for (int i = 0; i < size; i++) {
		if (munmap(addr[i], PAGE_SIZE * sizeof(uint8_t)) == -1) {
			printf("Fehler: Shared Memory kann nicht entfertn werden\n");
			return;
		}
	}
}


//liest Kategorien aus Datei von vollständiger Syscall Messung aus
char** get_categories(char* data_path) {
    FILE* fptr;
    char** category = malloc(NUMBER_OF_CATEGORIES * sizeof(char *));
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) category[i] = malloc(30 * sizeof(char));

    if ((fptr = fopen(data_path, "r+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei '%s': %d. Kategorien konnten nicht ausgelesen werden\e[39;0m\n",
               data_path, errno);
    }
    READ_CATEGORIES_ALL(fptr)
    fclose(fptr);
    return category;
}


int countlines(char* path) {
    FILE* fptr;
    char* line = NULL;
    size_t len = 0;
    ssize_t nread;
    int linecount = 0;

    if ((fptr = fopen(path, "ab+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s: %d. Berechnung von Anzahl enthaltener Zeilen fehlgeschlagen\e[39;0m\n",
               path, errno);
        return 0;
    }

    while ((nread = getline(&line, &len, fptr)) != -1) {
        linecount++;
    }

    free(line);
    fclose(fptr);
    return linecount;
}

void save_last_five_measurements(char* five_measurements_eval_path,char** category, uint64_t* val) {
    char* tmp_file = malloc(100 * sizeof(char));
    memset(tmp_file, '\0', 100 * sizeof(char));
    FILE* fptr_eval;
    FILE* fptr_tmp;
    int tmp_avg_c[NUMBER_OF_CATEGORIES];
    int num_lines;
    char* line = NULL;
    size_t len = 0;
    int count = 0;
    int same = 0;

    num_lines = countlines(five_measurements_eval_path);    //Zeilen in Datei zählen. MAX 6 = Kategorie Namen + 5 Messungen

    //Dateinamen für Temporäre Datei erstellen
    strncpy(tmp_file, five_measurements_eval_path, strlen(five_measurements_eval_path));
    strcat(tmp_file, "_TMP");

    //Quell-Datei öffnen
    if ((fptr_eval = fopen(five_measurements_eval_path, "r+")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s: %d. Weiteres Speichern von Durchschnittswerten nicht möglich\e[39;0m\n",
               five_measurements_eval_path, errno);
        return;
    }
    //Tmp-Datei öffnen
    if ((fptr_tmp = fopen(tmp_file, "wb")) == NULL) {
        printf("\e[31;1mFehler beim Öffnen der Datei %s: %d. Weiteres Speichern von Durchschnittswerten nicht möglich\e[39;0m\n",
               tmp_file, errno);
        return;
    }


    if (num_lines > 1 && num_lines <= 6) { //Es ist mind. 1 Messung vorhanden
        //Prüfe ob aktuelle Werte bereits vorhanden
        //Zu vorletzter Zeile springen
        for (int i = 0; i < num_lines - 1; i++) {
            getline(&line, &len, fptr_eval);
        }
        //letzte Zeile auslesen
        fscanf(fptr_eval, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
               &tmp_avg_c[0], &tmp_avg_c[1], &tmp_avg_c[2], &tmp_avg_c[3], &tmp_avg_c[4], &tmp_avg_c[5], &tmp_avg_c[6],
               &tmp_avg_c[7], &tmp_avg_c[8], &tmp_avg_c[9], &tmp_avg_c[10], &tmp_avg_c[11], &tmp_avg_c[12],
               &tmp_avg_c[13], &tmp_avg_c[14], &tmp_avg_c[15], &tmp_avg_c[16], &tmp_avg_c[17], &tmp_avg_c[18],
               &tmp_avg_c[19], &tmp_avg_c[20], &tmp_avg_c[21], &tmp_avg_c[22], &tmp_avg_c[23], &tmp_avg_c[24],
               &tmp_avg_c[25]);

        //letzte Zeile mit zu schreibenden Werten vergleichen
        for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
            if (tmp_avg_c[i] != val[i]) {
                same = 1;
            }
        }
        if (same == 0) {            //Messung schon enthalten, nichts zu tun.
            free(line);
            fclose(fptr_tmp);
            fclose(fptr_eval);
            remove(tmp_file);
            free(tmp_file);
            return;
        } else {
            //Messung noch nicht enthalten
            rewind(fptr_eval); //Zurück zu Anfang der Datei
            getline(&line, &len, fptr_eval); //Zeile mit Kategorien überspringen
        }


        //Beginne Schreiben
        fprintf(fptr_tmp, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
                category[0], category[1], category[2], category[3], category[4], category[5], category[6], category[7],
                category[8], category[9], category[10], category[11], category[12], category[13], category[14],
                category[15], category[16], category[17], category[18], category[19], category[20], category[21],
                category[22], category[23], category[24], category[25]); //Kategorien in Tmp-Datei schreiben
        while (fscanf(fptr_eval, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
                      &tmp_avg_c[0], &tmp_avg_c[1], &tmp_avg_c[2], &tmp_avg_c[3], &tmp_avg_c[4], &tmp_avg_c[5],
                      &tmp_avg_c[6], &tmp_avg_c[7], &tmp_avg_c[8], &tmp_avg_c[9], &tmp_avg_c[10], &tmp_avg_c[11],
                      &tmp_avg_c[12], &tmp_avg_c[13], &tmp_avg_c[14], &tmp_avg_c[15], &tmp_avg_c[16], &tmp_avg_c[17],
                      &tmp_avg_c[18], &tmp_avg_c[19], &tmp_avg_c[20], &tmp_avg_c[21], &tmp_avg_c[22], &tmp_avg_c[23],
                      &tmp_avg_c[24], &tmp_avg_c[25]) != EOF) {
            if (num_lines == 6 && count ==
                                  0) { //Wenn Bereits 5 Messungen vorhanden überspringe die erste beim schreiben in Tmp-Datei - FIFO
                count++;
                continue;
            }
            fprintf(fptr_tmp, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
                    tmp_avg_c[0], tmp_avg_c[1], tmp_avg_c[2], tmp_avg_c[3], tmp_avg_c[4], tmp_avg_c[5], tmp_avg_c[6],
                    tmp_avg_c[7], tmp_avg_c[8], tmp_avg_c[9], tmp_avg_c[10], tmp_avg_c[11], tmp_avg_c[12],
                    tmp_avg_c[13], tmp_avg_c[14], tmp_avg_c[15], tmp_avg_c[16], tmp_avg_c[17], tmp_avg_c[18],
                    tmp_avg_c[19], tmp_avg_c[20], tmp_avg_c[21], tmp_avg_c[22], tmp_avg_c[23], tmp_avg_c[24],
                    tmp_avg_c[25]);
            count++;
        }
        //Neue Messung hinzufügen
        fprintf(fptr_tmp,
                "%lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n",
                val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7], val[8], val[9], val[10], val[11],
                val[12], val[13], val[14], val[15], val[16], val[17], val[18], val[19], val[20], val[21], val[22],
                val[23], val[24], val[25]);


    } else { //Keine bisherigen Messungen vorhanden
        fprintf(fptr_tmp, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
                category[0], category[1], category[2], category[3], category[4], category[5], category[6], category[7],
                category[8], category[9], category[10], category[11], category[12], category[13], category[14],
                category[15], category[16], category[17], category[18], category[19], category[20], category[21],
                category[22], category[23], category[24], category[25]); //Kategorien in Tmp-Datei schreiben
        fprintf(fptr_tmp,
                "%lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n",
                val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7], val[8], val[9], val[10], val[11],
                val[12], val[13], val[14], val[15], val[16], val[17], val[18], val[19], val[20], val[21], val[22],
                val[23], val[24], val[25]);
    }


    printf("Die Durchschnittsergebnisse der letzten maximal 5 Systemcall Performance Messungen befinden sich in '%s'\n", five_measurements_eval_path);

    fclose(fptr_tmp);
    fclose(fptr_eval);
    rename(tmp_file, five_measurements_eval_path);
    remove(tmp_file);
    free(tmp_file);
    free(line);
}


uint64_t* avg(char* path) {
    FILE* fptr;
    char* line = NULL;
    size_t len = 0;
    int count = 0;
    int val_c[NUMBER_OF_CATEGORIES];
    uint64_t* avg_c = malloc(NUMBER_OF_CATEGORIES * sizeof(uint64_t));
    memset(avg_c, '\0', NUMBER_OF_CATEGORIES * sizeof(uint64_t));

    //Dateien mit Messungen bei KPTI und NOPTI öffnen
    if ((fptr = fopen(path, "r")) == NULL) {
        printf("\e[31mFehler beim Öffnen der Datei '%s'\e[39m\n", path);
        return avg_c;
    }

    //Datei lesen und Spaltendurchschnitt berechnen
    getline(&line, &len, fptr); //Zeile mit Kategorien überspringen
    while (fscanf(fptr, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n", &val_c[0],
                  &val_c[1], &val_c[2], &val_c[3], &val_c[4], &val_c[5], &val_c[6],
                  &val_c[7], &val_c[8], &val_c[9], &val_c[10], &val_c[11], &val_c[12],
                  &val_c[13], &val_c[14], &val_c[15], &val_c[16], &val_c[17],
                  &val_c[18], &val_c[19], &val_c[20], &val_c[21], &val_c[22], &val_c[23], &val_c[24], &val_c[25]) != EOF) {
        //Für Durchschnitt: Werte pro Spalte addieren
        for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) avg_c[i] += val_c[i];
        count++;    //Zeilen zählen
    }
    //Durchschnitt pro Spalte berechnen
    for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
        avg_c[i] /= count;
    }
    free(line);
    fclose(fptr);

    return avg_c;
}



#endif
