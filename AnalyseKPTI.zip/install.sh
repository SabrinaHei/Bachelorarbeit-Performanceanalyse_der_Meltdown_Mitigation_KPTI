##!/bin/bash

sudo apt update
sudo apt install make
sudo apt install gnuplot gnuplot-x11 gnuplot-doc
sudo apt install clang
sudo apt install cpuid
mkdir ./code/obj
chmod +x ./code/grub_settings/s_grub_kpti.sh
chmod +x ./code/grub_settings/s_grub_nopti.sh
echo "\n############################################"
echo "# Installation Fertig. Führe Makefile aus: #"
echo "############################################"
make
